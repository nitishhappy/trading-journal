// ===================== Firebase setup =====================
const firebaseConfig = {
  apiKey: "AIzaSyDw4UTL7v7sfWf1TnM6SJ92q89-8OxPxJo",
  authDomain: "trade-journal-4271e.firebaseapp.com",
  projectId: "trade-journal-4271e",
  storageBucket: "trade-journal-4271e.firebasestorage.app",
  messagingSenderId: "699891654756",
  appId: "1:699891654756:web:0f57bdd4112183dca0ff71",
  measurementId: "G-LMX876Y9D3"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// ===================== State =====================
let currentUser = null;
let observations = [];      // all observations for current user
let folders = ["Behaviour", "Technical", "To Do"]; // default + custom
let activeFolder = "all";
let editingObsId = null;     // set when editing an existing observation
let copyTargetObsId = null;  // set when copying an observation to a folder
let activeView = "dashboard"; // dashboard | summary | tradelog | settings
let groupMode = "date";       // date | priority | tags — current dashboard grouping
let defaultGroupMode = "date"; // persisted user preference
let expandedTileId = null;    // currently expanded tile (only one at a time)
let trades = [];              // trade log entries
let editingTradeId = null;
let showArchived = false;     // dashboard: show archived observations
let imagePendingOnly = false; // dashboard: filter to image-pending observations
let activeTagFilter = null;   // dashboard: filter to a specific tag
let allTags = [];              // distinct list of all tags ever used, for autosuggest

// ---- Revision mode state ----
let revisionQueue = [];        // ordered list of observation ids left to review today
let revisionReviewedIds = [];  // ids marked "reviewed" today (persisted)
let revisionFlaggedIds = [];   // ids marked "needs attention" today (persisted)
let revisionDragState = null;  // active drag tracking for the top card

// ===================== Element refs =====================
const authScreen = document.getElementById("auth-screen");
const appScreen = document.getElementById("app-screen");
const authForm = document.getElementById("auth-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const authError = document.getElementById("auth-error");
const loginBtn = document.getElementById("login-btn");
const signupBtn = document.getElementById("signup-btn");

const folderTabs = document.getElementById("folder-tabs");
const addFolderTab = document.getElementById("add-folder-tab");
const currentFolderLabel = document.getElementById("current-folder-label");
const searchInput = document.getElementById("search-input");
const groupSelect = document.getElementById("group-select");
const activeTagFilterBtn = document.getElementById("active-tag-filter");
const imagePendingToggle = document.getElementById("image-pending-toggle");
const archiveToggle = document.getElementById("archive-toggle");
const feed = document.getElementById("feed");
const emptyState = document.getElementById("empty-state");
const fabAdd = document.getElementById("fab-add");
const fullscreenBtn = document.getElementById("fullscreen-btn");
const themeToggleBtn = document.getElementById("theme-toggle-btn");
const metaThemeColor = document.getElementById("meta-theme-color");
const obsEntryTemplate = document.getElementById("obs-entry-template");
const obsModalBody = document.getElementById("obs-modal-body");
const obsAddAnotherBtn = document.getElementById("obs-add-another-btn");
const obsArchiveBtn = document.getElementById("obs-archive-btn");

// Revision view
const revisionStage = document.getElementById("revision-stage");
const revisionEmptyState = document.getElementById("revision-empty-state");
const revisionEmptyText = document.getElementById("revision-empty-text");
const revisionProgressText = document.getElementById("revision-progress-text");
const revisionProgressFill = document.getElementById("revision-progress-fill");
const revisionResetBtn = document.getElementById("revision-reset-btn");

// Main tab navigation
const mainTabs = document.getElementById("main-tabs");
const viewDashboard = document.getElementById("view-dashboard");
const viewInstalearning = document.getElementById("view-instalearning");
const viewRevision = document.getElementById("view-revision");
const viewAiCoach = document.getElementById("view-aicoach");
const viewTradelog = document.getElementById("view-tradelog");
const viewSettings = document.getElementById("view-settings");
const settingsGearBtn = document.getElementById("settings-gear-btn");
const settingsCloseBtn = document.getElementById("settings-close-btn");

// Settings panel: open/close via gear icon (slide-in overlay, not a tab)
settingsGearBtn.addEventListener("click", () => {
  viewSettings.classList.add("settings-open");
  currentFolderLabel.textContent = "Settings";
  loadSettingsKeyStatus();
  renderChecklistManageSelect();
});

settingsCloseBtn.addEventListener("click", () => {
  viewSettings.classList.remove("settings-open");
  // Restore label
  currentFolderLabel.textContent = activeView === "dashboard"
    ? (activeFolder === "all" ? "Dashboard" : activeFolder)
    : activeView.charAt(0).toUpperCase() + activeView.slice(1);
});

// Settings
const defaultSortSelect = document.getElementById("default-sort-select");
const settingsLogoutBtn = document.getElementById("settings-logout-btn");

// (Suggestion banners are now per-entry, queried dynamically within each .obs-entry block)

// Trade log
const tradeSearchInput = document.getElementById("trade-search-input");
const tradeExportBtn = document.getElementById("trade-export-btn");
const tradeAnalytics = document.getElementById("trade-analytics");
const tradeTableHead = document.getElementById("trade-table-head");
const tradeTableBody = document.getElementById("trade-table-body");
const tradeEmptyState = document.getElementById("trade-empty-state");
const fabAddTrade = document.getElementById("fab-add-trade");

const tradeModal = document.getElementById("trade-modal");
const tradeModalTitle = document.getElementById("trade-modal-title");
const tradeModalClose = document.getElementById("trade-modal-close");
const tradeDate = document.getElementById("trade-date");
const tradeCapital = document.getElementById("trade-capital");
const tradeNum = document.getElementById("trade-num");
const tradeGross = document.getElementById("trade-gross");
const tradeNet = document.getElementById("trade-net");
const tradeDuration = document.getElementById("trade-duration");
const tradeComments = document.getElementById("trade-comments");
const tradeSaveBtn = document.getElementById("trade-save-btn");
const tradeCancelBtn = document.getElementById("trade-cancel-btn");
const tradeDeleteBtn = document.getElementById("trade-delete-btn");

const obsModal = document.getElementById("obs-modal");
const obsModalTitle = document.getElementById("obs-modal-title");
const obsModalClose = document.getElementById("obs-modal-close");
const obsSaveBtn = document.getElementById("obs-save-btn");
const obsCancelBtn = document.getElementById("obs-cancel-btn");
const obsDeleteBtn = document.getElementById("obs-delete-btn");

const copyModal = document.getElementById("copy-modal");
const copyModalClose = document.getElementById("copy-modal-close");
const copyFolderSelect = document.getElementById("copy-folder-select");
const copyPrioritySelect = document.getElementById("copy-priority-select");
const copyCancelBtn = document.getElementById("copy-cancel-btn");
const copyConfirmBtn = document.getElementById("copy-confirm-btn");

const folderModal = document.getElementById("folder-modal");
const folderModalClose = document.getElementById("folder-modal-close");
const newFolderName = document.getElementById("new-folder-name");
const folderCancelBtn = document.getElementById("folder-cancel-btn");
const folderConfirmBtn = document.getElementById("folder-confirm-btn");

const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
const lightboxClose = document.getElementById("lightbox-close");

const toastEl = document.getElementById("toast");

// ===================== Toast =====================
let toastTimer = null;
function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.add("hidden"), 2200);
}

// ===================== Auth =====================
authForm.addEventListener("submit", (e) => {
  e.preventDefault();
  doLogin();
});

signupBtn.addEventListener("click", () => doSignup());

function doLogin() {
  authError.textContent = "";
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  auth.signInWithEmailAndPassword(email, password)
    .catch((err) => { authError.textContent = friendlyAuthError(err); });
}

function doSignup() {
  authError.textContent = "";
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if (!email || !password) {
    authError.textContent = "Enter email and password to create an account.";
    return;
  }
  auth.createUserWithEmailAndPassword(email, password)
    .catch((err) => { authError.textContent = friendlyAuthError(err); });
}

function friendlyAuthError(err) {
  switch (err.code) {
    case "auth/invalid-email": return "That email address looks invalid.";
    case "auth/user-not-found": return "No account found with that email.";
    case "auth/wrong-password": return "Incorrect password.";
    case "auth/email-already-in-use": return "An account already exists with that email.";
    case "auth/weak-password": return "Password should be at least 6 characters.";
    case "auth/invalid-credential": return "Invalid email or password.";
    default: return err.message;
  }
}

auth.onAuthStateChanged((user) => {
  currentUser = user;
  if (user) {
    authScreen.classList.add("hidden");
    appScreen.classList.remove("hidden");
    loadFolders();
    loadSettings();
    loadThemePreference();
    subscribeObservations();
    subscribeTrades();
    subscribeAiSummaries();
    subscribeILItems();
    loadChecklists();
  } else {
    appScreen.classList.add("hidden");
    authScreen.classList.remove("hidden");
    observations = [];
    trades = [];
    cachedGeminiKey = null;
    if (obsUnsubscribe) obsUnsubscribe();
    if (folderUnsubscribe) folderUnsubscribe();
    if (tradeUnsubscribe) tradeUnsubscribe();
    if (coachUnsubscribe) coachUnsubscribe();
    if (ilUnsubscribe) ilUnsubscribe();
  }
});

// ===================== Main tab navigation =====================
mainTabs.addEventListener("click", (e) => {
  const tab = e.target.closest(".main-tab");
  if (!tab) return;
  activeView = tab.dataset.view;
  document.querySelectorAll(".main-tab").forEach((t) => t.classList.remove("active"));
  tab.classList.add("active");

  [viewDashboard, viewInstalearning, viewRevision, viewAiCoach, viewTradelog].forEach((v) => v.classList.add("hidden"));

  if (activeView === "dashboard") {
    viewDashboard.classList.remove("hidden");
    currentFolderLabel.textContent = activeFolder === "all" ? "Dashboard" : activeFolder;
    renderFeed();
  } else if (activeView === "instalearning") {
    viewInstalearning.classList.remove("hidden");
    currentFolderLabel.textContent = "InstaLearn";
    renderILFeed();
  } else if (activeView === "revision") {
    viewRevision.classList.remove("hidden");
    currentFolderLabel.textContent = "Revision";
    renderRevisionStage();
  } else if (activeView === "aicoach") {
    viewAiCoach.classList.remove("hidden");
    currentFolderLabel.textContent = "AI Coach";
    renderAiCoachFeed();
  } else if (activeView === "tradelog") {
    viewTradelog.classList.remove("hidden");
    currentFolderLabel.textContent = "Trade Log";
    renderTradeTable();
  }
});

// ===================== Settings =====================
function loadSettings() {
  const ref = db.collection("users").doc(currentUser.uid).collection("settings").doc("preferences");
  ref.get().then((doc) => {
    if (doc.exists) {
      const data = doc.data();
      if (data.defaultGroup) {
        defaultGroupMode = data.defaultGroup;
        groupMode = defaultGroupMode;
      } else if (data.defaultSort) {
        // migrate old setting name
        defaultGroupMode = data.defaultSort;
        groupMode = defaultGroupMode;
      }
    }
    defaultSortSelect.value = defaultGroupMode;
    groupSelect.value = groupMode;
    renderFeed();
  }).catch((err) => {
    console.error("settings load error", err);
  });
}

defaultSortSelect.addEventListener("change", async () => {
  defaultGroupMode = defaultSortSelect.value;
  const ref = db.collection("users").doc(currentUser.uid).collection("settings").doc("preferences");
  try {
    await ref.set({ defaultGroup: defaultGroupMode }, { merge: true });
    showToast("Default grouping saved");
  } catch (err) {
    console.error(err);
    showToast("Could not save setting");
  }
});

settingsLogoutBtn.addEventListener("click", () => auth.signOut());

// ===================== Group control =====================
groupSelect.addEventListener("change", () => {
  groupMode = groupSelect.value;
  renderFeed();
});

// ===================== Image-pending / archive toggles =====================
imagePendingToggle.addEventListener("click", () => {
  imagePendingOnly = !imagePendingOnly;
  imagePendingToggle.classList.toggle("active", imagePendingOnly);
  renderFeed();
});

archiveToggle.addEventListener("click", () => {
  showArchived = !showArchived;
  archiveToggle.classList.toggle("active", showArchived);
  renderFeed();
});

// ===================== Tag click filter =====================
activeTagFilterBtn.addEventListener("click", () => {
  activeTagFilter = null;
  activeTagFilterBtn.classList.add("hidden");
  renderFeed();
});

function setTagFilter(tag) {
  activeTagFilter = tag;
  activeTagFilterBtn.textContent = `#${tag} ✕`;
  activeTagFilterBtn.classList.remove("hidden");
  renderFeed();
}

// ===================== Fullscreen toggle =====================
fullscreenBtn.addEventListener("click", () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch((err) => {
      showToast("Fullscreen not available");
    });
  } else {
    document.exitFullscreen();
  }
});

// ===================== Theme (light / dark) =====================
let currentTheme = "dark";

function applyTheme(theme, persist) {
  currentTheme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  const isDark = theme === "dark";
  themeToggleBtn.textContent = isDark ? "🌙" : "☀️";
  themeToggleBtn.title = isDark ? "Switch to light mode" : "Switch to dark mode";
  metaThemeColor.setAttribute("content", isDark ? "#0A0E17" : "#F0F4FA");
  // Sync the settings switch
  const sw = document.getElementById("settings-theme-toggle");
  if (sw) sw.classList.toggle("is-light", !isDark);
  if (persist && currentUser) {
    db.collection("users").doc(currentUser.uid)
      .collection("settings").doc("preferences")
      .set({ theme }, { merge: true })
      .catch((err) => console.error("theme save error", err));
  }
}

// Settings page switch handler (wired up when Settings view loads)
document.getElementById("settings-theme-toggle").addEventListener("click", () => {
  applyTheme(currentTheme === "dark" ? "light" : "dark", true);
});

function loadThemePreference() {
  // 1. Check Firestore preference
  db.collection("users").doc(currentUser.uid)
    .collection("settings").doc("preferences")
    .get()
    .then((doc) => {
      if (doc.exists && doc.data().theme) {
        applyTheme(doc.data().theme, false);
      } else {
        // 2. Fall back to OS preference
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        applyTheme(prefersDark ? "dark" : "light", false);
      }
    })
    .catch(() => {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      applyTheme(prefersDark ? "dark" : "light", false);
    });
}

themeToggleBtn.addEventListener("click", () => {
  applyTheme(currentTheme === "dark" ? "light" : "dark", true);
});

// Apply OS preference immediately before auth loads (avoids flash)
(function() {
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  document.documentElement.setAttribute("data-theme", prefersDark ? "dark" : "light");
  if (!prefersDark) metaThemeColor.setAttribute("content", "#F0F4FA");
})();

// ===================== Firestore: folders =====================
let folderUnsubscribe = null;

function loadFolders() {
  const ref = db.collection("users").doc(currentUser.uid).collection("folders");
  folderUnsubscribe = ref.onSnapshot((snap) => {
    const customFolders = [];
    snap.forEach((doc) => customFolders.push(doc.data().name));
    // Merge defaults with any custom ones, preserving order, no duplicates
    const defaults = ["Behaviour", "Technical", "To Do"];
    const merged = [...defaults];
    customFolders.forEach((f) => { if (!merged.includes(f)) merged.push(f); });
    folders = merged;
    renderFolderTabs();
    populateFolderSelects();
  }, (err) => {
    console.error("folders load error", err);
    // fall back to defaults
    renderFolderTabs();
    populateFolderSelects();
  });
}

function addCustomFolder(name) {
  const ref = db.collection("users").doc(currentUser.uid).collection("folders");
  return ref.add({ name, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
}

// ===================== Auto-categorization (rule-based, free) =====================
// Maps a target folder name -> list of keywords. Matching is case-insensitive,
// checked against observation text + tags. First folder with the most keyword
// hits wins (ties broken by order below).
const CATEGORY_RULES = {
  "Technical": [
    "support", "resistance", "breakout", "breakdown", "trendline", "indicator",
    "rsi", "macd", "moving average", "ema", "sma", "volume", "chart pattern",
    "candlestick", "fibonacci", "pattern", "setup", "level", "consolidation",
    "divergence", "vwap", "bollinger"
  ],
  "Implementation Issue": [
    "bug", "error", "crash", "delay", "slippage", "missed", "wrong order",
    "execution", "glitch", "freeze", "lag", "didn't trigger", "failed",
    "broker issue", "platform issue", "connectivity", "order rejected", "not working"
  ],
  "Behaviour": [
    "fomo", "fear", "greed", "anxious", "anxiety", "discipline", "impulsive",
    "revenge trade", "overtrading", "patience", "confidence", "hesitation",
    "panic", "emotional", "mindset", "stress", "frustrated", "overconfident"
  ],
  "To Do": [
    "todo", "to-do", "need to", "should check", "follow up", "remember to",
    "plan to", "next time", "review later", "pending", "action item"
  ],
};

// Returns { category, score } for the best matching category, or null if no match.
// category may or may not correspond to an existing folder.
function suggestCategory(text, tags) {
  const haystack = ((text || "") + " " + (tags || []).join(" ")).toLowerCase();
  let best = null;
  for (const [category, keywords] of Object.entries(CATEGORY_RULES)) {
    let score = 0;
    keywords.forEach((kw) => {
      if (haystack.includes(kw.toLowerCase())) score++;
    });
    if (score > 0 && (!best || score > best.score)) {
      best = { category, score };
    }
  }
  return best;
}

// ===================== Firestore: observations =====================
let obsUnsubscribe = null;

function subscribeObservations() {
  const ref = db.collection("users").doc(currentUser.uid).collection("observations")
    .orderBy("createdAt", "desc");
  obsUnsubscribe = ref.onSnapshot((snap) => {
    observations = [];
    snap.forEach((doc) => {
      const data = doc.data();
      observations.push({ id: doc.id, ...data });
    });
    updateAllTags();
    updateStreakBadge();
    if (activeView === "dashboard") renderFeed();
    if (activeView === "revision") renderRevisionStage();
  }, (err) => {
    console.error("observations load error", err);
    showToast("Failed to load observations");
  });
}

function updateAllTags() {
  const set = new Set();
  observations.forEach((o) => (o.tags || []).forEach((t) => set.add(t)));
  allTags = Array.from(set).sort((a, b) => a.localeCompare(b));
}

// ---- Comma-aware tag autocomplete ----
// Native <input list="..."> datalists match against the WHOLE field value,
// so they stop suggesting anything as soon as a comma + a second tag is being
// typed. This builds a small custom dropdown that only looks at the segment
// after the last comma, and inserts the chosen tag back into that position.
function attachTagAutocomplete(input) {
  if (!input || input.dataset.autocompleteAttached) return;
  input.dataset.autocompleteAttached = "1";

  // Wrap the input in a positioned container so the dropdown anchors directly
  // beneath it, regardless of where this input sits in the page/modal.
  const wrapper = document.createElement("div");
  wrapper.className = "tag-autocomplete-wrapper";
  input.parentNode.insertBefore(wrapper, input);
  wrapper.appendChild(input);

  const dropdown = document.createElement("div");
  dropdown.className = "tag-autocomplete-dropdown hidden";
  wrapper.appendChild(dropdown);

  let activeIndex = -1;
  let currentMatches = [];

  function getCurrentSegment() {
    const value = input.value;
    const caret = input.selectionStart ?? value.length;
    const upToCaret = value.slice(0, caret);
    const lastComma = upToCaret.lastIndexOf(",");
    return upToCaret.slice(lastComma + 1).trim().toLowerCase();
  }

  function getAlreadyUsedTags() {
    return input.value.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean);
  }

  function closeDropdown() {
    dropdown.classList.add("hidden");
    dropdown.innerHTML = "";
    activeIndex = -1;
    currentMatches = [];
  }

  function openDropdownWithMatches(segment) {
    const used = getAlreadyUsedTags();
    currentMatches = allTags
      .filter((t) => t.toLowerCase().includes(segment) && !used.includes(t.toLowerCase()))
      .slice(0, 8);

    if (segment.length === 0 || currentMatches.length === 0) {
      closeDropdown();
      return;
    }

    dropdown.innerHTML = "";
    currentMatches.forEach((tag, i) => {
      const item = document.createElement("div");
      item.className = "tag-autocomplete-item";
      item.textContent = tag;
      item.addEventListener("mousedown", (e) => {
        e.preventDefault(); // keep focus in input
        selectTag(tag);
      });
      dropdown.appendChild(item);
    });
    activeIndex = -1;
    dropdown.classList.remove("hidden");
  }

  function selectTag(tag) {
    const value = input.value;
    const caret = input.selectionStart ?? value.length;
    const upToCaret = value.slice(0, caret);
    const afterCaret = value.slice(caret);
    const lastComma = upToCaret.lastIndexOf(",");

    const before = lastComma === -1 ? "" : value.slice(0, lastComma + 1) + " ";
    const newValue = before + tag + ", " + afterCaret.replace(/^[^,]*/, "").replace(/^,\s*/, "");
    input.value = newValue.replace(/,\s*,/g, ",").trim();
    const newCaret = (before + tag + ", ").length;
    input.focus();
    input.setSelectionRange(newCaret, newCaret);
    closeDropdown();
  }

  input.addEventListener("input", () => {
    const segment = getCurrentSegment();
    openDropdownWithMatches(segment);
  });

  input.addEventListener("keydown", (e) => {
    if (dropdown.classList.contains("hidden")) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      activeIndex = Math.min(activeIndex + 1, currentMatches.length - 1);
      updateActiveHighlight();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      activeIndex = Math.max(activeIndex - 1, 0);
      updateActiveHighlight();
    } else if (e.key === "Enter" && activeIndex >= 0) {
      e.preventDefault();
      selectTag(currentMatches[activeIndex]);
    } else if (e.key === "Escape") {
      closeDropdown();
    }
  });

  function updateActiveHighlight() {
    [...dropdown.children].forEach((el, i) => el.classList.toggle("active", i === activeIndex));
  }

  input.addEventListener("blur", () => {
    // Delay so a mousedown-selection on the dropdown can register first
    setTimeout(closeDropdown, 150);
  });
}

function saveObservation(obsData, id) {
  const col = db.collection("users").doc(currentUser.uid).collection("observations");
  if (id) {
    return col.doc(id).update(obsData);
  } else {
    obsData.createdAt = firebase.firestore.FieldValue.serverTimestamp();
    return col.add(obsData);
  }
}

function deleteObservation(id) {
  return db.collection("users").doc(currentUser.uid).collection("observations").doc(id).delete();
}

// ===================== Folder tabs =====================
function renderFolderTabs() {
  // Remove existing dynamic tabs (keep "All" and the add button)
  const existing = folderTabs.querySelectorAll(".tab:not([data-folder='all']):not(.tab-add)");
  existing.forEach((el) => el.remove());

  folders.forEach((f) => {
    const btn = document.createElement("button");
    btn.className = "tab";
    btn.dataset.folder = f;
    btn.textContent = f;
    if (f === activeFolder) btn.classList.add("active");
    folderTabs.insertBefore(btn, addFolderTab);
  });

  // Re-attach "All" active state
  const allTab = folderTabs.querySelector('[data-folder="all"]');
  allTab.classList.toggle("active", activeFolder === "all");
}

folderTabs.addEventListener("click", (e) => {
  const tab = e.target.closest(".tab");
  if (!tab || tab.id === "add-folder-tab") return;
  activeFolder = tab.dataset.folder;
  document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
  tab.classList.add("active");
  currentFolderLabel.textContent = activeFolder === "all" ? "Dashboard" : activeFolder;
  renderFeed();
});

addFolderTab.addEventListener("click", () => {
  newFolderName.value = "";
  folderModal.classList.remove("hidden");
  setTimeout(() => newFolderName.focus(), 50);
});

folderModalClose.addEventListener("click", () => folderModal.classList.add("hidden"));
folderCancelBtn.addEventListener("click", () => folderModal.classList.add("hidden"));

folderConfirmBtn.addEventListener("click", async () => {
  const name = newFolderName.value.trim();
  if (!name) return;
  if (folders.includes(name)) {
    showToast("Folder already exists");
    return;
  }
  try {
    await addCustomFolder(name);
    folderModal.classList.add("hidden");
    showToast(`Folder "${name}" created`);
  } catch (err) {
    console.error(err);
    showToast("Could not create folder");
  }
});

// ===================== Search =====================
searchInput.addEventListener("input", () => renderFeed());

const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 };

// ===================== Render feed =====================
function renderFeed() {
  feed.innerHTML = "";
  const query = searchInput.value.trim().toLowerCase();

  let filtered = observations.filter((o) => {
    // Archive filter
    const isArchived = !!o.archived;
    if (showArchived) {
      if (!isArchived) return false;
    } else {
      if (isArchived) return false;
    }

    // Image-pending filter
    if (imagePendingOnly && !o.imagePending) return false;

    // Tag filter (click-to-filter)
    if (activeTagFilter && !(o.tags || []).includes(activeTagFilter)) return false;

    // Folder filter: check primary folder + any extra folders/priorities map
    if (activeFolder !== "all") {
      const inFolders = getObsFolders(o);
      if (!inFolders.includes(activeFolder)) return false;
    }
    if (query) {
      const inText = (o.text || "").toLowerCase().includes(query);
      const inTags = (o.tags || []).some((t) => t.toLowerCase().includes(query));
      if (!inText && !inTags) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  if (groupMode === "priority") {
    renderFeedByPriority(filtered);
  } else if (groupMode === "tags") {
    renderFeedByTags(filtered);
  } else {
    renderFeedByDate(filtered);
  }
}

function getDisplayPriority(o) {
  let p = o.priority || "medium";
  if (activeFolder !== "all" && o.folderPriorities && o.folderPriorities[activeFolder]) {
    p = o.folderPriorities[activeFolder];
  }
  return p;
}

function getCreatedTime(o) {
  return o.createdAt && o.createdAt.toDate ? o.createdAt.toDate().getTime() : 0;
}

// Sort by priority (high -> low), then newest first — used within each date group
function sortByPriorityThenDate(arr) {
  return [...arr].sort((a, b) => {
    const pa = PRIORITY_ORDER[getDisplayPriority(a)] ?? 1;
    const pb = PRIORITY_ORDER[getDisplayPriority(b)] ?? 1;
    if (pa !== pb) return pa - pb;
    return getCreatedTime(b) - getCreatedTime(a);
  });
}

function appendGroup(headerText, items) {
  const groupEl = document.createElement("div");
  groupEl.className = "date-group";

  const header = document.createElement("div");
  header.className = "date-header";
  header.textContent = headerText;
  groupEl.appendChild(header);

  const itemsEl = document.createElement("div");
  itemsEl.className = "date-group-items";
  items.forEach((o) => itemsEl.appendChild(renderTile(o)));
  groupEl.appendChild(itemsEl);

  feed.appendChild(groupEl);
}

function renderFeedByDate(filtered) {
  // Group by date (createdAt)
  const groups = {};
  filtered.forEach((o) => {
    const dateKey = getDateKey(o.createdAt);
    if (!groups[dateKey]) groups[dateKey] = [];
    groups[dateKey].push(o);
  });

  // groups already roughly sorted desc because observations are ordered by createdAt desc.
  // Within each day, sort by priority (high first), then newest first.
  Object.keys(groups).forEach((dateKey) => {
    const items = sortByPriorityThenDate(groups[dateKey]);
    appendGroup(formatDateHeader(dateKey), items);
  });
}

function renderFeedByPriority(filtered) {
  const sorted = [...filtered].sort((a, b) => {
    const pa = PRIORITY_ORDER[getDisplayPriority(a)] ?? 1;
    const pb = PRIORITY_ORDER[getDisplayPriority(b)] ?? 1;
    if (pa !== pb) return pa - pb;
    return getCreatedTime(b) - getCreatedTime(a);
  });

  const groups = { high: [], medium: [], low: [] };
  sorted.forEach((o) => {
    const p = getDisplayPriority(o);
    if (groups[p]) groups[p].push(o);
  });

  const labels = { high: "High priority", medium: "Medium priority", low: "Low priority" };

  ["high", "medium", "low"].forEach((p) => {
    if (groups[p].length === 0) return;
    appendGroup(labels[p], groups[p]);
  });
}

function renderFeedByTags(filtered) {
  // Group observations by each tag (an observation with multiple tags appears in multiple groups)
  const groups = {}; // tag -> items
  const untagged = [];
  filtered.forEach((o) => {
    const tags = o.tags || [];
    if (tags.length === 0) {
      untagged.push(o);
    } else {
      tags.forEach((t) => {
        if (!groups[t]) groups[t] = [];
        groups[t].push(o);
      });
    }
  });

  // Sort tags alphabetically; within each tag group, sort by priority then date
  Object.keys(groups).sort((a, b) => a.localeCompare(b)).forEach((tag) => {
    const items = sortByPriorityThenDate(groups[tag]);
    appendGroup("#" + tag, items);
  });

  if (untagged.length > 0) {
    appendGroup("Untagged", sortByPriorityThenDate(untagged));
  }
}

function getObsFolders(o) {
  // Primary folder + any folders from folderPriorities map
  const set = new Set();
  if (o.folder) set.add(o.folder);
  if (o.folderPriorities) {
    Object.keys(o.folderPriorities).forEach((f) => set.add(f));
  }
  return Array.from(set);
}

function getDateKey(timestamp) {
  if (!timestamp) return "unknown";
  const d = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}

// Local-date key (not UTC) — used for the streak so a late-evening entry
// in the user's own timezone counts toward "today" correctly.
function getLocalDateKey(timestamp) {
  if (!timestamp) return null;
  const d = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

const streakBadge = document.getElementById("streak-badge");

// Computes the current "journaling streak": consecutive calendar days
// (in the user's local timezone), ending today or yesterday, with at
// least one non-archived observation logged.
function computeStreak() {
  const daysWithEntries = new Set();
  observations.forEach((o) => {
    if (o.archived) return;
    const key = getLocalDateKey(o.createdAt);
    if (key) daysWithEntries.add(key);
  });

  if (daysWithEntries.size === 0) return 0;

  const today = new Date();
  const todayKeyLocal = getLocalDateKey({ toDate: () => today });

  // Walk backwards from today. If today has no entry yet, the streak is
  // still considered "alive" as long as yesterday had one — the user just
  // hasn't logged today yet. If yesterday is also missing, streak is 0.
  let cursor = new Date(today);
  if (!daysWithEntries.has(todayKeyLocal)) {
    cursor.setDate(cursor.getDate() - 1);
    const yesterdayKey = getLocalDateKey({ toDate: () => cursor });
    if (!daysWithEntries.has(yesterdayKey)) return 0;
  }

  let streak = 0;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const key = getLocalDateKey({ toDate: () => cursor });
    if (!daysWithEntries.has(key)) break;
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

function updateStreakBadge() {
  const streak = computeStreak();
  if (streak <= 0) {
    streakBadge.classList.add("hidden");
    return;
  }
  streakBadge.classList.remove("hidden");
  streakBadge.classList.toggle("streak-hot", streak >= 7);
  streakBadge.textContent = `🔥 ${streak} day${streak !== 1 ? "s" : ""}`;
}

function formatDateHeader(dateKey) {
  if (dateKey === "unknown") return "Unsorted";
  const d = new Date(dateKey + "T00:00:00");
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  const isSameDay = (a, b) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  if (isSameDay(d, today)) return "Today";
  if (isSameDay(d, yesterday)) return "Yesterday";

  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

function formatTime(timestamp) {
  if (!timestamp) return "";
  const d = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

// ===================== Render tile =====================
function renderTile(o) {
  const tile = document.createElement("div");

  const displayPriority = getDisplayPriority(o);
  const isExpanded = expandedTileId === o.id;

  tile.className = `tile priority-${displayPriority}` + (isExpanded ? " expanded" : "");

  const body = document.createElement("div");
  const hasImage = !!o.imageBase64;
  const hasLink = !!o.link;
  body.className = "tile-body" + (!hasImage && !hasLink ? " fill-text" : "");

  // ---- Collapsed preview content ----
  // Header row: small image thumb (if any) isn't shown collapsed; we show text + chevron
  const headerRow = document.createElement("div");
  headerRow.className = "tile-header-row";

  if (o.text) {
    const textEl = document.createElement("div");
    textEl.className = "tile-text";
    textEl.textContent = o.text;
    headerRow.appendChild(textEl);
  } else if (!hasImage && !hasLink) {
    const textEl = document.createElement("div");
    textEl.className = "tile-text";
    textEl.textContent = "(no text)";
    headerRow.appendChild(textEl);
  }

  const chevron = document.createElement("span");
  chevron.className = "expand-chevron";
  chevron.textContent = "▾";
  headerRow.appendChild(chevron);

  body.appendChild(headerRow);

  // Status badges (image pending / archived)
  if (o.imagePending || o.archived) {
    const badgeRow = document.createElement("div");
    badgeRow.className = "tile-badge-row";
    if (o.imagePending) {
      const badge = document.createElement("span");
      badge.className = "status-badge pending";
      badge.textContent = "Image pending";
      badgeRow.appendChild(badge);
    }
    if (o.archived) {
      const badge = document.createElement("span");
      badge.className = "status-badge archived";
      badge.textContent = "Archived";
      badgeRow.appendChild(badge);
    }
    body.appendChild(badgeRow);
  }

  // Collapsed image preview (compact) — only shown when collapsed
  if (hasImage && !isExpanded) {
    const img = document.createElement("img");
    img.className = "tile-image";
    img.src = o.imageBase64;
    img.alt = "Observation image";
    img.addEventListener("click", (e) => { e.stopPropagation(); openLightbox(o.imageBase64); });
    body.appendChild(img);
  }

  // Collapsed link preview
  if (hasLink && !isExpanded) {
    const linkEl = document.createElement("a");
    linkEl.className = "tile-link";
    linkEl.href = o.link;
    linkEl.target = "_blank";
    linkEl.rel = "noopener noreferrer";
    linkEl.textContent = "🔗 " + o.link;
    linkEl.addEventListener("click", (e) => e.stopPropagation());
    body.appendChild(linkEl);
  }

  // Meta row: tags + time (always visible)
  const meta = document.createElement("div");
  meta.className = "tile-meta";

  const tagsEl = document.createElement("div");
  tagsEl.className = "tile-tags";
  (o.tags || []).forEach((t) => {
    const chip = document.createElement("span");
    chip.className = "tag-chip clickable";
    chip.textContent = "#" + t;
    chip.addEventListener("click", (e) => {
      e.stopPropagation();
      setTagFilter(t);
    });
    tagsEl.appendChild(chip);
  });
  if (o.category) {
    const catPill = document.createElement("span");
    catPill.className = "category-pill";
    catPill.textContent = o.category;
    tagsEl.appendChild(catPill);
  }
  meta.appendChild(tagsEl);

  const timeEl = document.createElement("div");
  timeEl.className = "tile-time";
  timeEl.textContent = formatTime(o.createdAt);
  meta.appendChild(timeEl);

  body.appendChild(meta);

  // ---- Expanded content ----
  const expandContent = document.createElement("div");
  expandContent.className = "tile-expand-content";

  if (hasImage) {
    const img = document.createElement("img");
    img.className = "tile-image";
    img.src = o.imageBase64;
    img.alt = "Observation image";
    img.addEventListener("click", (e) => { e.stopPropagation(); openLightbox(o.imageBase64); });
    expandContent.appendChild(img);
  }

  if (hasLink) {
    const linkEl = document.createElement("a");
    linkEl.className = "tile-link";
    linkEl.href = o.link;
    linkEl.target = "_blank";
    linkEl.rel = "noopener noreferrer";
    linkEl.textContent = "🔗 " + o.link;
    linkEl.addEventListener("click", (e) => e.stopPropagation());
    expandContent.appendChild(linkEl);
  }

  // Folder/priority details
  const obsFolders = getObsFolders(o);
  if (obsFolders.length > 0) {
    const row = document.createElement("div");
    row.className = "tile-expand-row";
    const folderInfo = obsFolders.map((f) => {
      const p = (f === o.folder) ? (o.priority || "medium") : ((o.folderPriorities && o.folderPriorities[f]) || "medium");
      return `${f} (${p})`;
    }).join(", ");
    row.innerHTML = `<span><b>Folders:</b> ${escapeHtml(folderInfo)}</span>`;
    expandContent.appendChild(row);
  }

  const dateRow = document.createElement("div");
  dateRow.className = "tile-expand-row";
  const fullDate = o.createdAt && o.createdAt.toDate
    ? o.createdAt.toDate().toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })
    : "";
  dateRow.innerHTML = `<span><b>Logged:</b> ${escapeHtml(fullDate)}</span>`;
  expandContent.appendChild(dateRow);

  body.appendChild(expandContent);

  body.addEventListener("click", () => {
    expandedTileId = isExpanded ? null : o.id;
    renderFeed();
  });

  tile.appendChild(body);

  // Actions
  const actions = document.createElement("div");
  actions.className = "tile-actions";

  const editBtn = document.createElement("button");
  editBtn.className = "tile-action-btn";
  editBtn.innerHTML = "✎";
  editBtn.title = "Edit";
  editBtn.addEventListener("click", (e) => { e.stopPropagation(); openEditModal(o); });
  actions.appendChild(editBtn);

  const copyBtn = document.createElement("button");
  copyBtn.className = "tile-action-btn";
  copyBtn.innerHTML = "⧉";
  copyBtn.title = "Copy to folder";
  copyBtn.addEventListener("click", (e) => { e.stopPropagation(); openCopyModal(o); });
  actions.appendChild(copyBtn);

  tile.appendChild(actions);

  // Folder pills (only show in "All" view, and only if observation belongs to >1 folder or non-default)
  if (activeFolder === "all" && obsFolders.length > 1) {
    const wrapper = document.createElement("div");
    wrapper.style.display = "contents";
    const pillsEl = document.createElement("div");
    pillsEl.className = "folder-pills";
    obsFolders.forEach((f) => {
      const pill = document.createElement("span");
      pill.className = "folder-pill";
      pill.textContent = f;
      pillsEl.appendChild(pill);
    });
    body.insertBefore(pillsEl, expandContent);
  }

  return tile;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ===================== Lightbox =====================
const lightboxRotateBtn = document.getElementById("lightbox-rotate");
let lightboxRotation = 0;

function openLightbox(src) {
  lightboxImg.src = src;
  lightboxRotation = 0;
  lightboxImg.style.transform = "rotate(0deg)";
  lightboxImg.style.maxWidth = "";
  lightboxImg.style.maxHeight = "";
  lightbox.classList.remove("hidden");
}
lightboxClose.addEventListener("click", () => lightbox.classList.add("hidden"));
lightboxRotateBtn.addEventListener("click", () => {
  lightboxRotation = (lightboxRotation + 90) % 360;
  lightboxImg.style.transform = `rotate(${lightboxRotation}deg)`;
  const isSideways = lightboxRotation === 90 || lightboxRotation === 270;
  if (isSideways) {
    lightboxImg.style.maxWidth = "86vh";
    lightboxImg.style.maxHeight = "92vw";
  } else {
    lightboxImg.style.maxWidth = "92vw";
    lightboxImg.style.maxHeight = "86vh";
  }
});
lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) lightbox.classList.add("hidden");
});

// ===================== Observation Modal (Create/Edit) =====================
function populateFolderSelects() {
  [copyFolderSelect].forEach((sel) => {
    const currentVal = sel.value;
    sel.innerHTML = "";
    folders.forEach((f) => {
      const opt = document.createElement("option");
      opt.value = f;
      opt.textContent = f;
      sel.appendChild(opt);
    });
    if (folders.includes(currentVal)) sel.value = currentVal;
  });
}

function populateFolderSelect(sel, preferred) {
  sel.innerHTML = "";
  folders.forEach((f) => {
    const opt = document.createElement("option");
    opt.value = f;
    opt.textContent = f;
    sel.appendChild(opt);
  });
  if (preferred && folders.includes(preferred)) {
    sel.value = preferred;
  }
}

fabAdd.addEventListener("click", () => openCreateModal());

// Default folder for new observations: current active folder if it's a real folder,
// otherwise "Technical" if it exists, otherwise the first folder.
function getDefaultFolder() {
  if (activeFolder !== "all" && folders.includes(activeFolder)) return activeFolder;
  if (folders.includes("Technical")) return "Technical";
  return folders[0];
}

// ---- Build a single .obs-entry block from the template ----
function buildObsEntry(index) {
  const frag = obsEntryTemplate.content.cloneNode(true);
  const entry = frag.querySelector(".obs-entry");
  entry.dataset.index = index;

  const folderSel = entry.querySelector(".obs-folder");
  populateFolderSelect(folderSel, getDefaultFolder());

  // Remove button (only meaningful when there are multiple entries)
  const removeBtn = entry.querySelector(".obs-entry-remove");
  removeBtn.addEventListener("click", () => {
    entry.remove();
    updateObsEntryHeaders();
  });

  // Image handling
  const imageFile = entry.querySelector(".obs-image-file");
  const imagePreview = entry.querySelector(".obs-image-preview");
  const imagePreviewImg = entry.querySelector(".obs-image-preview-img");
  const imageRemove = entry.querySelector(".obs-image-remove");
  const imagePending = entry.querySelector(".obs-image-pending");

  imageFile.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      showToast("Please select an image file");
      return;
    }
    resizeImageToBase64(file, 1024, 0.7).then((base64) => {
      entry.dataset.imageBase64 = base64;
      imagePreviewImg.src = base64;
      imagePreview.classList.remove("hidden");
      // If an image is provided, image-pending no longer makes sense
      imagePending.checked = false;
    }).catch((err) => {
      console.error(err);
      showToast("Could not process image");
    });
  });

  imageRemove.addEventListener("click", () => {
    delete entry.dataset.imageBase64;
    imageFile.value = "";
    imagePreview.classList.add("hidden");
  });

  // Tag-based category suggestion (per entry)
  const textArea = entry.querySelector(".obs-text");
  const tagsInput = entry.querySelector(".obs-tags");
  attachTagAutocomplete(tagsInput);
  const suggestionBanner = entry.querySelector(".suggestion-banner");
  const suggestionText = entry.querySelector(".suggestion-text");
  const suggestionAccept = entry.querySelector(".suggestion-accept");
  const suggestionDismiss = entry.querySelector(".suggestion-dismiss");

  function hideSuggestion() {
    suggestionBanner.classList.add("hidden");
    entry.dataset.suggestedCategory = "";
  }

  function showSuggestion(category) {
    entry.dataset.suggestedCategory = category;
    const folderHint = folders.includes(category) ? ` and move it to that folder` : "";
    suggestionText.textContent = `This looks like a "${category}" observation. Tag it${folderHint}?`;
    suggestionBanner.classList.remove("hidden");
  }

  suggestionAccept.addEventListener("click", () => {
    const cat = entry.dataset.suggestedCategory;
    if (cat) {
      entry.dataset.category = cat;
      entry.dataset.lastDecidedCategory = cat;
      if (folders.includes(cat)) folderSel.value = cat;
      showToast(`Tagged as "${cat}"`);
    }
    hideSuggestion();
  });

  suggestionDismiss.addEventListener("click", () => {
    entry.dataset.lastDecidedCategory = entry.dataset.suggestedCategory || "";
    hideSuggestion();
  });

  let suggestionDebounce = null;
  textArea.addEventListener("input", () => {
    clearTimeout(suggestionDebounce);
    suggestionDebounce = setTimeout(() => {
      const tags = tagsInput.value.split(",").map((t) => t.trim()).filter(Boolean);
      const suggestion = suggestCategory(textArea.value, tags);
      if (suggestion && suggestion.category !== entry.dataset.lastDecidedCategory) {
        showSuggestion(suggestion.category);
      } else {
        hideSuggestion();
      }
    }, 500);
  });

  return entry;
}

function updateObsEntryHeaders() {
  const entries = obsModalBody.querySelectorAll(".obs-entry");
  entries.forEach((entry, i) => {
    const header = entry.querySelector(".obs-entry-header");
    const title = entry.querySelector(".obs-entry-title");
    if (entries.length > 1) {
      header.classList.remove("hidden");
      title.textContent = `Observation ${i + 1}`;
    } else {
      header.classList.add("hidden");
    }
  });
}

obsAddAnotherBtn.addEventListener("click", () => {
  const entries = obsModalBody.querySelectorAll(".obs-entry");
  const entry = buildObsEntry(entries.length);
  obsModalBody.appendChild(entry);
  updateObsEntryHeaders();
  entry.querySelector(".obs-text").focus();
});

function openCreateModal() {
  editingObsId = null;
  obsModalTitle.textContent = "New Observation";
  obsDeleteBtn.classList.add("hidden");
  obsArchiveBtn.classList.add("hidden");
  obsAddAnotherBtn.classList.remove("hidden");
  obsModalBody.innerHTML = "";
  const entry = buildObsEntry(0);
  obsModalBody.appendChild(entry);
  updateObsEntryHeaders();
  obsModal.classList.remove("hidden");
}

function openEditModal(o) {
  editingObsId = o.id;
  obsModalTitle.textContent = "Edit Observation";
  obsDeleteBtn.classList.remove("hidden");
  obsArchiveBtn.classList.remove("hidden");
  obsArchiveBtn.textContent = o.archived ? "Unarchive" : "Archive";
  obsAddAnotherBtn.classList.add("hidden"); // edit mode = single observation only

  obsModalBody.innerHTML = "";
  const entry = buildObsEntry(0);

  entry.querySelector(".obs-text").value = o.text || "";
  entry.querySelector(".obs-link").value = o.link || "";
  entry.querySelector(".obs-tags").value = (o.tags || []).join(", ");

  const imagePreview = entry.querySelector(".obs-image-preview");
  const imagePreviewImg = entry.querySelector(".obs-image-preview-img");
  if (o.imageBase64) {
    entry.dataset.imageBase64 = o.imageBase64;
    imagePreviewImg.src = o.imageBase64;
    imagePreview.classList.remove("hidden");
  }
  entry.querySelector(".obs-image-pending").checked = !!o.imagePending;

  populateFolderSelect(entry.querySelector(".obs-folder"), o.folder || folders[0]);
  entry.querySelector(".obs-priority").value = o.priority || "medium";

  // Category suggestion if not already tagged
  entry.dataset.category = o.category || "";
  entry.dataset.lastDecidedCategory = o.category || "";
  const suggestion = suggestCategory(o.text, o.tags);
  if (suggestion && suggestion.category !== o.category) {
    const folderHint = folders.includes(suggestion.category) ? ` and move it to that folder` : "";
    entry.dataset.suggestedCategory = suggestion.category;
    const banner = entry.querySelector(".suggestion-banner");
    entry.querySelector(".suggestion-text").textContent = `This looks like a "${suggestion.category}" observation. Tag it${folderHint}?`;
    banner.classList.remove("hidden");
  }

  obsModalBody.appendChild(entry);
  updateObsEntryHeaders();
  obsModal.classList.remove("hidden");
}

obsModalClose.addEventListener("click", () => obsModal.classList.add("hidden"));
obsCancelBtn.addEventListener("click", () => obsModal.classList.add("hidden"));

function resizeImageToBase64(file, maxDim, quality) {
  // GIFs must be read as-is (base64 passthrough) — drawing a GIF onto a
  // <canvas> and re-encoding as JPEG keeps only the first frame, killing
  // any animation. JPEG/PNG/WebP still get the resize+compress treatment
  // below to stay well under Firestore's ~1MB document size limit.
  if (file.type === "image/gif") {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = (e) => resolve(e.target.result);
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// Build a Firestore-ready obsData object from a .obs-entry element. Returns null (and shows
// a toast) if validation fails.
function entryToObsData(entry) {
  const text = entry.querySelector(".obs-text").value.trim();
  const link = entry.querySelector(".obs-link").value.trim();
  const tags = entry.querySelector(".obs-tags").value.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean);
  const folder = entry.querySelector(".obs-folder").value;
  const priority = entry.querySelector(".obs-priority").value;
  const imagePending = entry.querySelector(".obs-image-pending").checked;
  const imageBase64 = entry.dataset.imageBase64 || null;
  const category = entry.dataset.category || null;

  if (!text && !link && !imageBase64) {
    showToast("Add at least text, a link, or an image");
    return null;
  }

  if (link && !/^https?:\/\//i.test(link)) {
    showToast("Link should start with http:// or https://");
    return null;
  }

  if (imageBase64 && imageBase64.length > 900000) {
    showToast("Image too large, please choose a smaller one");
    return null;
  }

  return {
    text,
    link,
    tags,
    folder,
    priority,
    category,
    imageBase64,
    imagePending,
  };
}

obsSaveBtn.addEventListener("click", async () => {
  const entries = Array.from(obsModalBody.querySelectorAll(".obs-entry"));
  const obsDataList = [];
  for (const entry of entries) {
    const data = entryToObsData(entry);
    if (!data) return; // validation failed, toast already shown
    data.updatedAt = firebase.firestore.FieldValue.serverTimestamp();
    obsDataList.push(data);
  }

  obsSaveBtn.disabled = true;
  obsSaveBtn.textContent = "Saving…";
  try {
    if (editingObsId) {
      // Edit mode: single entry, preserve archived flag and folderPriorities
      const existing = observations.find((o) => o.id === editingObsId) || {};
      const data = obsDataList[0];
      data.archived = !!existing.archived;
      await saveObservation(data, editingObsId);
      obsModal.classList.add("hidden");
      showToast("Observation updated");
    } else {
      // Create mode: one or more new observations, each gets its own document
      for (const data of obsDataList) {
        data.archived = false;
        await saveObservation(data, null);
      }
      obsModal.classList.add("hidden");
      showToast(obsDataList.length > 1 ? `${obsDataList.length} observations saved` : "Observation saved");
    }
  } catch (err) {
    console.error(err);
    showToast("Save failed: " + err.message);
  } finally {
    obsSaveBtn.disabled = false;
    obsSaveBtn.textContent = "Save";
  }
});

obsDeleteBtn.addEventListener("click", async () => {
  if (!editingObsId) return;
  if (!confirm("Delete this observation? This cannot be undone.")) return;
  try {
    await deleteObservation(editingObsId);
    obsModal.classList.add("hidden");
    showToast("Observation deleted");
  } catch (err) {
    console.error(err);
    showToast("Delete failed");
  }
});

obsArchiveBtn.addEventListener("click", async () => {
  if (!editingObsId) return;
  const existing = observations.find((o) => o.id === editingObsId);
  const newArchived = !(existing && existing.archived);
  try {
    await db.collection("users").doc(currentUser.uid).collection("observations")
      .doc(editingObsId).update({ archived: newArchived });
    obsModal.classList.add("hidden");
    showToast(newArchived ? "Observation archived" : "Observation unarchived");
  } catch (err) {
    console.error(err);
    showToast("Could not update archive status");
  }
});

// ===================== Trade Log =====================

function makeStat(value, label) {
  const el = document.createElement("div");
  el.className = "summary-stat";
  el.innerHTML = `<div class="stat-value">${escapeHtml(String(value))}</div><div class="stat-label">${escapeHtml(label)}</div>`;
  return el;
}

function formatNum(n) {
  const num = Number(n) || 0;
  return num.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

// ===================== Trade Log =====================
// ===================== Trade Log =====================
let tradeUnsubscribe = null;

function subscribeTrades() {
  const ref = db.collection("users").doc(currentUser.uid).collection("tradeLogs")
    .orderBy("date", "desc");
  tradeUnsubscribe = ref.onSnapshot((snap) => {
    trades = [];
    snap.forEach((doc) => {
      trades.push({ id: doc.id, ...doc.data() });
    });
    if (activeView === "tradelog") renderTradeTable();
  }, (err) => {
    console.error("trades load error", err);
    showToast("Failed to load trade log");
  });
}

function saveTrade(data, id) {
  const col = db.collection("users").doc(currentUser.uid).collection("tradeLogs");
  if (id) return col.doc(id).update(data);
  return col.add(data);
}

function deleteTrade(id) {
  return db.collection("users").doc(currentUser.uid).collection("tradeLogs").doc(id).delete();
}

const TRADE_COLUMNS = [
  { key: "date", label: "Date" },
  { key: "capital", label: "Capital" },
  { key: "numTrades", label: "No. of Trades" },
  { key: "grossPL", label: "Gross P/L" },
  { key: "netPL", label: "Net P/L" },
  { key: "duration", label: "Duration" },
  { key: "comments", label: "Comments" },
];

tradeSearchInput.addEventListener("input", () => renderTradeTable());

function renderTradeTable() {
  tradeTableHead.innerHTML = "";
  tradeTableBody.innerHTML = "";

  TRADE_COLUMNS.forEach((col) => {
    const th = document.createElement("th");
    th.textContent = col.label;
    tradeTableHead.appendChild(th);
  });
  const actionTh = document.createElement("th");
  actionTh.textContent = "";
  tradeTableHead.appendChild(actionTh);

  const query = tradeSearchInput.value.trim().toLowerCase();
  const filtered = trades.filter((t) => {
    if (!query) return true;
    return (t.comments || "").toLowerCase().includes(query);
  });

  if (filtered.length === 0) {
    tradeEmptyState.classList.remove("hidden");
  } else {
    tradeEmptyState.classList.add("hidden");
  }

  filtered.forEach((t) => {
    const tr = document.createElement("tr");
    tr.addEventListener("click", () => openTradeModal(t));

    TRADE_COLUMNS.forEach((col) => {
      const td = document.createElement("td");
      let val = t[col.key];
      if (col.key === "comments") {
        td.className = "comments-cell";
        td.textContent = val || "";
      } else if (col.key === "grossPL" || col.key === "netPL") {
        const num = Number(val) || 0;
        td.textContent = formatNum(num);
        td.classList.add(num >= 0 ? "pl-positive" : "pl-negative");
      } else if (col.key === "capital") {
        td.textContent = val != null ? formatNum(val) : "";
      } else {
        td.textContent = val != null ? val : "";
      }
      tr.appendChild(td);
    });

    const actionTd = document.createElement("td");
    actionTd.textContent = "✎";
    actionTd.style.textAlign = "center";
    tr.appendChild(actionTd);

    tradeTableBody.appendChild(tr);
  });

  renderTradeAnalytics(filtered);
}

function renderTradeAnalytics(rows) {
  tradeAnalytics.innerHTML = "";
  if (rows.length === 0) return;

  const totalNet = rows.reduce((sum, t) => sum + (Number(t.netPL) || 0), 0);
  const totalGross = rows.reduce((sum, t) => sum + (Number(t.grossPL) || 0), 0);
  const totalTrades = rows.reduce((sum, t) => sum + (Number(t.numTrades) || 0), 0);
  const winDays = rows.filter((t) => (Number(t.netPL) || 0) > 0).length;
  const winRate = rows.length > 0 ? Math.round((winDays / rows.length) * 100) : 0;

  tradeAnalytics.appendChild(makeStat(formatNum(totalNet), "Total Net P/L"));
  tradeAnalytics.appendChild(makeStat(formatNum(totalGross), "Total Gross P/L"));
  tradeAnalytics.appendChild(makeStat(totalTrades, "Total Trades"));
  tradeAnalytics.appendChild(makeStat(`${winRate}%`, "Win-day rate"));
}

// CSV export
tradeExportBtn.addEventListener("click", () => {
  if (trades.length === 0) {
    showToast("No trade logs to export");
    return;
  }
  const headers = TRADE_COLUMNS.map((c) => c.label);
  const rows = trades.map((t) => TRADE_COLUMNS.map((c) => {
    const val = t[c.key];
    const str = val != null ? String(val) : "";
    // Escape CSV: wrap in quotes if it contains comma, quote, or newline
    if (/[",\n]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }).join(","));
  const csv = [headers.join(","), ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `trade-log-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("CSV downloaded");
});

// Trade modal
fabAddTrade.addEventListener("click", () => openTradeModal(null));

function openTradeModal(t) {
  if (t) {
    editingTradeId = t.id;
    tradeModalTitle.textContent = "Edit Trade Log";
    tradeDeleteBtn.classList.remove("hidden");
    tradeDate.value = t.date || "";
    tradeCapital.value = t.capital != null ? t.capital : "";
    tradeNum.value = t.numTrades != null ? t.numTrades : "";
    tradeGross.value = t.grossPL != null ? t.grossPL : "";
    tradeNet.value = t.netPL != null ? t.netPL : "";
    tradeDuration.value = t.duration || "";
    tradeComments.value = t.comments || "";
  } else {
    editingTradeId = null;
    tradeModalTitle.textContent = "New Trade Log";
    tradeDeleteBtn.classList.add("hidden");
    tradeDate.value = new Date().toISOString().slice(0, 10);
    tradeCapital.value = "";
    tradeNum.value = "";
    tradeGross.value = "";
    tradeNet.value = "";
    tradeDuration.value = "";
    tradeComments.value = "";
  }
  tradeModal.classList.remove("hidden");
}

tradeModalClose.addEventListener("click", () => tradeModal.classList.add("hidden"));
tradeCancelBtn.addEventListener("click", () => tradeModal.classList.add("hidden"));

tradeSaveBtn.addEventListener("click", async () => {
  const date = tradeDate.value;
  if (!date) {
    showToast("Date is required");
    return;
  }

  const data = {
    date,
    capital: tradeCapital.value !== "" ? Number(tradeCapital.value) : null,
    numTrades: tradeNum.value !== "" ? Number(tradeNum.value) : null,
    grossPL: tradeGross.value !== "" ? Number(tradeGross.value) : null,
    netPL: tradeNet.value !== "" ? Number(tradeNet.value) : null,
    duration: tradeDuration.value.trim(),
    comments: tradeComments.value.trim(),
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
  };
  if (!editingTradeId) {
    data.createdAt = firebase.firestore.FieldValue.serverTimestamp();
  }

  tradeSaveBtn.disabled = true;
  tradeSaveBtn.textContent = "Saving…";
  try {
    await saveTrade(data, editingTradeId);
    tradeModal.classList.add("hidden");
    showToast(editingTradeId ? "Trade log updated" : "Trade log saved");
  } catch (err) {
    console.error(err);
    showToast("Save failed: " + err.message);
  } finally {
    tradeSaveBtn.disabled = false;
    tradeSaveBtn.textContent = "Save";
  }
});

tradeDeleteBtn.addEventListener("click", async () => {
  if (!editingTradeId) return;
  if (!confirm("Delete this trade log entry? This cannot be undone.")) return;
  try {
    await deleteTrade(editingTradeId);
    tradeModal.classList.add("hidden");
    showToast("Trade log deleted");
  } catch (err) {
    console.error(err);
    showToast("Delete failed");
  }
});
function openCopyModal(o) {
  copyTargetObsId = o.id;
  populateFolderSelects();
  // Default to first folder that isn't already assigned, else first folder
  const existingFolders = getObsFolders(o);
  const candidate = folders.find((f) => !existingFolders.includes(f)) || folders[0];
  copyFolderSelect.value = candidate;
  copyPrioritySelect.value = "medium";
  copyModal.classList.remove("hidden");
}

copyModalClose.addEventListener("click", () => copyModal.classList.add("hidden"));
copyCancelBtn.addEventListener("click", () => copyModal.classList.add("hidden"));

copyConfirmBtn.addEventListener("click", async () => {
  const targetFolder = copyFolderSelect.value;
  const targetPriority = copyPrioritySelect.value;
  const obs = observations.find((o) => o.id === copyTargetObsId);
  if (!obs) return;

  const folderPriorities = { ...(obs.folderPriorities || {}) };
  folderPriorities[targetFolder] = targetPriority;

  try {
    await db.collection("users").doc(currentUser.uid).collection("observations")
      .doc(copyTargetObsId)
      .update({ folderPriorities });
    copyModal.classList.add("hidden");
    showToast(`Added to "${targetFolder}"`);
  } catch (err) {
    console.error(err);
    showToast("Could not copy to folder");
  }
});

// ===================== Revision mode =====================
// Today's reviewed/flagged ids are persisted in Firestore under
// users/{uid}/revisionState/{YYYY-MM-DD} so progress survives reloads,
// and only resets when the user taps "Reset" (per the chosen design).

function todayKey() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function revisionStateRef() {
  return db.collection("users").doc(currentUser.uid).collection("revisionState").doc(todayKey());
}

let revisionStateLoaded = false;

function loadRevisionState() {
  return revisionStateRef().get().then((doc) => {
    if (doc.exists) {
      const data = doc.data();
      revisionReviewedIds = data.reviewed || [];
      revisionFlaggedIds = data.flagged || [];
    } else {
      revisionReviewedIds = [];
      revisionFlaggedIds = [];
    }
    revisionStateLoaded = true;
  }).catch((err) => {
    console.error("revision state load error", err);
    revisionReviewedIds = [];
    revisionFlaggedIds = [];
    revisionStateLoaded = true;
  });
}

function saveRevisionState() {
  return revisionStateRef().set({
    reviewed: revisionReviewedIds,
    flagged: revisionFlaggedIds,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
  }, { merge: true }).catch((err) => {
    console.error("revision state save error", err);
  });
}

// Build the ordered queue of observation ids still needing review today:
// non-archived, not yet reviewed today, ordered by date (newest day first)
// then priority (high -> low) then newest-created-first within that.
function buildRevisionQueue() {
  const candidates = observations.filter((o) => !o.archived && !revisionReviewedIds.includes(o.id));

  const sorted = [...candidates].sort((a, b) => {
    // Flagged ("needs attention") items sort to the back, so other cards are
    // seen first before circling back to ones already flagged this session.
    const aFlagged = revisionFlaggedIds.includes(a.id);
    const bFlagged = revisionFlaggedIds.includes(b.id);
    if (aFlagged !== bFlagged) return aFlagged ? 1 : -1;

    const da = getDateKey(a.createdAt);
    const db_ = getDateKey(b.createdAt);
    if (da !== db_) return da < db_ ? 1 : -1; // newest date first
    const pa = PRIORITY_ORDER[getDisplayPriority(a)] ?? 1;
    const pb = PRIORITY_ORDER[getDisplayPriority(b)] ?? 1;
    if (pa !== pb) return pa - pb; // high priority first
    return getCreatedTime(b) - getCreatedTime(a);
  });

  revisionQueue = sorted.map((o) => o.id);
}

function getRevisionTotalCount() {
  return observations.filter((o) => !o.archived).length;
}

async function renderRevisionStage() {
  revisionStage.innerHTML = "";

  if (!revisionStateLoaded) {
    await loadRevisionState();
  }

  buildRevisionQueue();
  updateRevisionProgress();

  if (revisionQueue.length === 0) {
    revisionEmptyState.classList.remove("hidden");
    revisionStage.classList.add("hidden");
    const total = getRevisionTotalCount();
    if (total === 0) {
      revisionEmptyText.textContent = "No observations to review yet.";
    } else {
      revisionEmptyText.textContent = "All caught up for today.";
    }
    return;
  }

  revisionEmptyState.classList.add("hidden");
  revisionStage.classList.remove("hidden");

  // Render up to 2 cards (top + peek of next) for a stacked look
  const idsToRender = revisionQueue.slice(0, 2);
  // Render in reverse so the first id ends up on top (last child = topmost via z-index)
  idsToRender.slice().reverse().forEach((id, i) => {
    const obs = observations.find((o) => o.id === id);
    if (!obs) return;
    const isTop = (id === idsToRender[0]);
    const card = buildRevisionCard(obs, isTop);
    revisionStage.appendChild(card);
  });
}

function updateRevisionProgress() {
  const total = getRevisionTotalCount();
  const remaining = revisionQueue.length;
  const done = total - remaining;
  revisionProgressText.textContent = `${done} / ${total}`;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  revisionProgressFill.style.width = pct + "%";
}

function buildRevisionCard(o, isTop) {
  const card = document.createElement("div");
  card.className = `revision-card priority-${getDisplayPriority(o)}`;
  card.dataset.obsId = o.id;
  if (!isTop) {
    card.style.transform = "scale(0.97) translateY(8px)";
    card.style.opacity = "0.6";
    card.style.zIndex = "1";
    card.style.pointerEvents = "none";
  } else {
    card.classList.add("revision-card-top");
    card.style.zIndex = "2";
  }

  const hasImage = !!o.imageBase64;
  const hasLink = !!o.link;
  if (!hasImage && !hasLink) card.classList.add("text-only");

  // Meta row: date + folders
  const meta = document.createElement("div");
  meta.className = "revision-card-meta";
  const dateSpan = document.createElement("span");
  dateSpan.textContent = formatDateHeader(getDateKey(o.createdAt)) + " · " + formatTime(o.createdAt);
  meta.appendChild(dateSpan);

  const obsFolders = getObsFolders(o);
  if (obsFolders.length > 0) {
    const folderSpan = document.createElement("span");
    folderSpan.className = "revision-card-folders";
    folderSpan.textContent = obsFolders.join(", ");
    meta.appendChild(folderSpan);
  }

  if (revisionFlaggedIds.includes(o.id)) {
    const flagSpan = document.createElement("span");
    flagSpan.className = "revision-card-flagged-badge";
    flagSpan.textContent = "⚑ Flagged earlier";
    meta.appendChild(flagSpan);
  }
  card.appendChild(meta);

  // Image
  if (hasImage) {
    const img = document.createElement("img");
    img.className = "revision-card-image";
    img.src = o.imageBase64;
    img.alt = "Observation image";
    img.addEventListener("click", (e) => { e.stopPropagation(); openLightbox(o.imageBase64); });
    card.appendChild(img);
  }

  // Text
  if (o.text) {
    const textEl = document.createElement("div");
    textEl.className = "revision-card-text";
    textEl.textContent = o.text;
    card.appendChild(textEl);
  } else {
    const textEl = document.createElement("div");
    textEl.className = "revision-card-text";
    textEl.textContent = "(no text)";
    textEl.style.color = "var(--text-dim)";
    card.appendChild(textEl);
  }

  // Link
  if (o.link) {
    const linkEl = document.createElement("a");
    linkEl.className = "revision-card-link";
    linkEl.href = o.link;
    linkEl.target = "_blank";
    linkEl.rel = "noopener noreferrer";
    linkEl.textContent = "🔗 " + o.link;
    linkEl.addEventListener("click", (e) => e.stopPropagation());
    card.appendChild(linkEl);
  }

  // Tags
  if ((o.tags || []).length > 0) {
    const tagsEl = document.createElement("div");
    tagsEl.className = "revision-card-tags";
    (o.tags || []).forEach((t) => {
      const chip = document.createElement("span");
      chip.className = "tag-chip";
      chip.textContent = "#" + t;
      tagsEl.appendChild(chip);
    });
    card.appendChild(tagsEl);
  }

  // Swipe hints
  const hintRight = document.createElement("div");
  hintRight.className = "revision-card-hint right";
  hintRight.textContent = "Reviewed";
  card.appendChild(hintRight);

  const hintLeft = document.createElement("div");
  hintLeft.className = "revision-card-hint left";
  hintLeft.textContent = "Attention";
  card.appendChild(hintLeft);

  if (isTop) {
    attachSwipeHandlers(card, o);
  }

  return card;
}

// ---- Swipe gesture handling (pointer events cover touch + mouse) ----
// Also supports long-press to edit the observation without leaving Revision mode.
function attachSwipeHandlers(card, obs) {
  const hintRight = card.querySelector(".revision-card-hint.right");
  const hintLeft = card.querySelector(".revision-card-hint.left");

  let startX = 0, startY = 0, currentX = 0, dragging = false, horizontalIntent = null;
  let longPressTimer = null;
  let longPressFired = false;
  const LONG_PRESS_MS = 500;
  const LONG_PRESS_MOVE_TOLERANCE = 10;

  function clearLongPressTimer() {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
  }

  function onPointerDown(e) {
    // Don't start a drag from interactive elements (links, images that open lightbox)
    if (e.target.closest("a")) return;
    dragging = true;
    horizontalIntent = null;
    startX = e.clientX;
    startY = e.clientY;
    currentX = 0;
    longPressFired = false;
    card.classList.add("dragging");
    card.setPointerCapture && card.setPointerCapture(e.pointerId);

    clearLongPressTimer();
    longPressTimer = setTimeout(() => {
      // Only fire if the finger/pointer hasn't moved meaningfully (so it doesn't
      // trigger mid-swipe) and no horizontal swipe intent has been established.
      if (dragging && horizontalIntent !== true) {
        longPressFired = true;
        card.classList.remove("dragging");
        card.style.transform = "";
        if (hintRight) hintRight.style.opacity = 0;
        if (hintLeft) hintLeft.style.opacity = 0;
        if (navigator.vibrate) navigator.vibrate(15);
        openEditModal(obs);
      }
    }, LONG_PRESS_MS);
  }

  function onPointerMove(e) {
    if (!dragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    // Cancel the long-press timer once the pointer has moved beyond a small
    // tolerance — that movement means the user is swiping or scrolling, not holding.
    if (Math.abs(dx) > LONG_PRESS_MOVE_TOLERANCE || Math.abs(dy) > LONG_PRESS_MOVE_TOLERANCE) {
      clearLongPressTimer();
    }

    // Decide gesture direction once enough movement has happened.
    // This stops vertical scrolling (long text/images) from being hijacked,
    // while still letting horizontal swipes work for the review action.
    if (horizontalIntent === null && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) {
      horizontalIntent = Math.abs(dx) > Math.abs(dy);
    }
    if (horizontalIntent === false) return; // let the browser handle vertical scroll natively

    e.preventDefault();
    currentX = dx;
    const rotate = currentX / 18;
    card.style.transform = `translate(${currentX}px, ${dy * 0.1}px) rotate(${rotate}deg)`;

    const threshold = 60;
    if (currentX > threshold) {
      hintRight.style.opacity = Math.min(1, (currentX - threshold) / 60);
      hintLeft.style.opacity = 0;
    } else if (currentX < -threshold) {
      hintLeft.style.opacity = Math.min(1, (-currentX - threshold) / 60);
      hintRight.style.opacity = 0;
    } else {
      hintRight.style.opacity = 0;
      hintLeft.style.opacity = 0;
    }
  }

  function onPointerUp() {
    clearLongPressTimer();
    if (!dragging) return;
    dragging = false;
    card.classList.remove("dragging");

    if (longPressFired) { horizontalIntent = null; return; } // edit modal already opened
    if (horizontalIntent === false) { horizontalIntent = null; return; }

    const SWIPE_THRESHOLD = 100;
    if (currentX > SWIPE_THRESHOLD) {
      completeSwipe(card, "right");
    } else if (currentX < -SWIPE_THRESHOLD) {
      completeSwipe(card, "left");
    } else {
      // snap back
      card.style.transform = "";
      hintRight.style.opacity = 0;
      hintLeft.style.opacity = 0;
    }
    horizontalIntent = null;
  }

  card.addEventListener("pointerdown", onPointerDown);
  card.addEventListener("pointermove", onPointerMove);
  card.addEventListener("pointerup", onPointerUp);
  card.addEventListener("pointercancel", onPointerUp);
}

// direction: "right" = reviewed, "left" = needs attention
async function completeSwipe(card, direction) {
  const obsId = card.dataset.obsId;
  card.classList.add(direction === "right" ? "swipe-right" : "swipe-left");

  if (direction === "right") {
    // Reviewed — clear any "needs attention" flag too, since it's been handled now.
    if (!revisionReviewedIds.includes(obsId)) revisionReviewedIds.push(obsId);
    revisionFlaggedIds = revisionFlaggedIds.filter((id) => id !== obsId);
  } else {
    // Needs attention — do NOT mark as reviewed, so it keeps reappearing in the
    // queue (at the back, see buildRevisionQueue) until it's swiped right.
    if (!revisionFlaggedIds.includes(obsId)) revisionFlaggedIds.push(obsId);
  }

  await saveRevisionState();

  setTimeout(() => {
    if (activeView === "revision") renderRevisionStage();
  }, 300);
}

revisionResetBtn.addEventListener("click", async () => {
  if (!confirm("Reset today's review progress? All observations will reappear in the revision queue.")) return;
  revisionReviewedIds = [];
  revisionFlaggedIds = [];
  await saveRevisionState();
  showToast("Revision progress reset");
  renderRevisionStage();
});

// ===================== AI Coach tab =====================
// Calls Gemini API directly from the browser — no Cloud Functions needed.
// The API key is stored once in Firestore under users/{uid}/settings/apiKeys
// so it never appears in source code. It's protected by your Firestore login rules.
// Using Groq (free forever, no credit card) — get key at console.groq.com
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "llama-3.3-70b-versatile"; // best free model on Groq for analysis

const COACH_SYSTEM_INSTRUCTION = `You are a professional trading psychologist and performance coach reviewing a trader's daily journal observations.

Your job is to find repeated behavioural patterns and identify WHY the trader is making mistakes — not to describe individual trades.

Structure your response in clear markdown with these sections (omit a section only if there is truly nothing relevant):

## Knowledge Issues
Gaps in market understanding, technical analysis, or strategy knowledge that show up repeatedly.

## Execution Issues
Problems in how trades are entered, managed, or exited — hesitation, impulsiveness, poor timing, deviation from plan.

## New Learnings
Genuine insights, breakthroughs, or positive adjustments the trader has identified.

## Discipline
Patterns related to rule-following, emotional control, FOMO, revenge trading, overtrading, patience.

## Stage-wise Patterns
Break down patterns by trading stage where evident: Pre-market preparation, Analysis/setup identification, Execution (entry), Trade management (stops/targets/holding).

Be specific, reference recurring themes across multiple observations rather than one-off events, and be direct about root causes. Keep the tone constructive but honest.`;

let coachPeriod = "weekly";
let aiSummaries = [];
let coachUnsubscribe = null;
let cachedGeminiKey = null; // in-memory cache so we don't re-fetch every time

const coachGenerateBtn = document.getElementById("coach-generate-btn");
const coachGenerating = document.getElementById("coach-generating");
const coachEmpty = document.getElementById("coach-empty");
const coachFeed = document.getElementById("coach-feed");

// ---- API key storage in Firestore ----
async function loadGeminiKey() {
  if (cachedGeminiKey) return cachedGeminiKey;
  try {
    const doc = await db.collection("users").doc(currentUser.uid)
      .collection("settings").doc("apiKeys").get();
    if (doc.exists && doc.data().geminiKey) {
      cachedGeminiKey = doc.data().geminiKey;
      return cachedGeminiKey;
    }
  } catch (e) { console.error("loadGeminiKey", e); }
  return null;
}

async function saveGeminiKey(key) {
  await db.collection("users").doc(currentUser.uid)
    .collection("settings").doc("apiKeys")
    .set({ geminiKey: key }, { merge: true });
  cachedGeminiKey = key;
}

// ---- Period toggle ----
document.querySelector(".coach-controls").addEventListener("click", (e) => {
  const btn = e.target.closest(".seg-btn[data-coach-period]");
  if (!btn) return;
  coachPeriod = btn.dataset.coachPeriod;
  document.querySelectorAll(".seg-btn[data-coach-period]").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  renderAiCoachFeed();
});

// ---- Generate now button ----
coachGenerateBtn.addEventListener("click", async () => {
  if (!currentUser) return;

  // Check for API key first
  let apiKey = await loadGeminiKey();
  if (!apiKey) {
    apiKey = prompt("Enter your Gemini API key (from aistudio.google.com/apikey).\nIt will be saved securely to your account.");
    if (!apiKey || !apiKey.trim()) return;
    await saveGeminiKey(apiKey.trim());
    apiKey = apiKey.trim();
  }

  setCoachGenerating(true);
  try {
    const result = await generateCoachSummaryClient(apiKey, coachPeriod);
    if (result.skipped) {
      showToast("Nothing to summarise: " + result.reason);
    } else {
      showToast("AI Coach summary generated ✦");
      // Firestore listener auto-refreshes the feed
    }
  } catch (err) {
    console.error("coach generate error:", err);
    // If it looks like an auth error, clear cached key so user can re-enter
    if (err.message && (err.message.includes("Invalid API Key") || err.message.includes("401") || err.message.includes("403") || err.message.includes("api_key"))) {
      cachedGeminiKey = null;
      showToast("Invalid Groq key — go to Settings to update it");
    } else {
      showToast("Error: " + (err.message || "Could not generate summary"));
    }
  } finally {
    setCoachGenerating(false);
  }
});

function setCoachGenerating(on) {
  coachGenerateBtn.disabled = on;
  coachGenerateBtn.textContent = on ? "Generating…" : "✦ Generate now";
  coachGenerating.classList.toggle("hidden", !on);
  if (on) {
    coachFeed.classList.add("hidden");
    coachEmpty.classList.add("hidden");
  } else {
    coachFeed.classList.remove("hidden");
  }
}

// ---- Core: build journal text → call Gemini → save to Firestore ----
async function generateCoachSummaryClient(apiKey, periodType) {
  const now = new Date();
  const endDate = new Date(now);
  const startDate = new Date(now);
  if (periodType === "weekly") {
    startDate.setDate(startDate.getDate() - 7);
  } else {
    startDate.setMonth(startDate.getMonth() - 1);
  }

  // Filter observations in range, non-archived, with text content
  const inRange = observations.filter((o) => {
    if (o.archived) return false;
    if (!o.text && !o.link) return false;
    const ts = o.createdAt && o.createdAt.toDate ? o.createdAt.toDate() : null;
    if (!ts) return false;
    return ts >= startDate && ts <= endDate;
  });

  // Sort oldest first for the AI to read chronologically
  inRange.sort((a, b) => getCreatedTime(a) - getCreatedTime(b));

  if (inRange.length === 0) {
    return { skipped: true, reason: `No observations in the past ${periodType === "weekly" ? "7 days" : "30 days"}` };
  }

  const lines = inRange.map((o) => {
    const date = getDateKey(o.createdAt);
    const folder = o.folder || "Uncategorized";
    const priority = o.priority || "medium";
    const tags = (o.tags || []).join(", ");
    let entry = `[${date}] (${folder}, priority: ${priority}${tags ? ", tags: " + tags : ""})\n${o.text || ""}`;
    if (o.link) entry += `\nLink: ${o.link}`;
    return entry;
  });

  const periodLabel = periodType === "weekly" ? "past 7 days" : "past 30 days";
  const prompt = `Analyze these ${lines.length} trading journal entries from the ${periodLabel} (${startDate.toISOString().slice(0,10)} to ${endDate.toISOString().slice(0,10)}) and provide a deep psychological performance review:\n\n${lines.join("\n---\n")}`;

  // Call Groq API (OpenAI-compatible format)
  const body = {
    model: GROQ_MODEL,
    messages: [
      { role: "system", content: COACH_SYSTEM_INSTRUCTION },
      { role: "user", content: prompt }
    ],
    temperature: 0.7,
    max_tokens: 2048,
  };

  const resp = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const errBody = await resp.json().catch(() => ({}));
    const msg = errBody.error && errBody.error.message ? errBody.error.message : `HTTP ${resp.status}`;
    throw new Error(msg);
  }

  const data = await resp.json();
  const summaryText = data.choices?.[0]?.message?.content;
  if (!summaryText) throw new Error("Empty response from Groq");

  // Save to Firestore
  await db.collection("users").doc(currentUser.uid).collection("aiSummaries").add({
    type: periodType,
    content: summaryText,
    entryCount: lines.length,
    periodStart: firebase.firestore.Timestamp.fromDate(startDate),
    periodEnd: firebase.firestore.Timestamp.fromDate(endDate),
    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
  });

  return { skipped: false, entryCount: lines.length };
}

// ---- Subscribe to saved summaries (real-time) ----
function subscribeAiSummaries() {
  if (coachUnsubscribe) coachUnsubscribe();
  if (!currentUser) return;
  const ref = db.collection("users").doc(currentUser.uid).collection("aiSummaries")
    .orderBy("createdAt", "desc").limit(20);
  coachUnsubscribe = ref.onSnapshot((snap) => {
    aiSummaries = [];
    snap.forEach((doc) => aiSummaries.push({ id: doc.id, ...doc.data() }));
    if (activeView === "aicoach") renderAiCoachFeed();
  }, (err) => console.error("aiSummaries subscription error:", err));
}

function renderAiCoachFeed() {
  if (!coachGenerating.classList.contains("hidden")) return;
  coachFeed.classList.remove("hidden");
  const filtered = aiSummaries.filter((s) => s.type === coachPeriod);
  if (filtered.length === 0) {
    coachFeed.innerHTML = "";
    coachEmpty.classList.remove("hidden");
    return;
  }
  coachEmpty.classList.add("hidden");
  coachFeed.innerHTML = "";
  filtered.forEach((s, i) => coachFeed.appendChild(buildCoachCard(s, i === 0)));
}

function buildCoachCard(s, startExpanded) {
  const card = document.createElement("div");
  card.className = "coach-summary-card" + (startExpanded ? " expanded" : "");

  const header = document.createElement("div");
  header.className = "coach-summary-header";
  header.addEventListener("click", () => card.classList.toggle("expanded"));

  const typeBadge = document.createElement("span");
  typeBadge.className = "coach-summary-type";
  typeBadge.textContent = s.type === "weekly" ? "Weekly" : "Monthly";
  header.appendChild(typeBadge);

  const dateEl = document.createElement("span");
  dateEl.className = "coach-summary-date";
  const startDate = s.periodStart && s.periodStart.toDate
    ? s.periodStart.toDate().toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "";
  const endDate = s.periodEnd && s.periodEnd.toDate
    ? s.periodEnd.toDate().toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "";
  const createdDate = s.createdAt && s.createdAt.toDate
    ? s.createdAt.toDate().toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "";
  dateEl.textContent = startDate && endDate ? `${startDate} – ${endDate}` : createdDate;
  header.appendChild(dateEl);

  const metaEl = document.createElement("span");
  metaEl.className = "coach-summary-meta";
  metaEl.textContent = s.entryCount ? `${s.entryCount} entries` : "";
  header.appendChild(metaEl);

  const chevron = document.createElement("span");
  chevron.className = "coach-summary-chevron";
  chevron.textContent = "▾";
  header.appendChild(chevron);

  card.appendChild(header);

  const body = document.createElement("div");
  body.className = "coach-summary-body";
  body.innerHTML = simpleMarkdownToHtml(s.content || "");
  card.appendChild(body);

  return card;
}

// Lightweight markdown → safe HTML (covers typical Gemini output)
function simpleMarkdownToHtml(md) {
  let html = md
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/```[\s\S]*?```/g, "")
    .replace(/^---+$/gm, "<hr>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^[*-] (.+)$/gm, "<li>$1</li>")
    .replace(/^\d+\. (.+)$/gm, "<li>$1</li>");

  html = html.replace(/(<li>[\s\S]*?<\/li>)(\s*<li>[\s\S]*?<\/li>)*/g, (m) => `<ul>${m}</ul>`);
  html = html.split(/\n{2,}/).map((block) => {
    block = block.trim();
    if (!block) return "";
    if (/^<(h[23]|ul|ol|hr|li)/.test(block)) return block;
    return `<p>${block.replace(/\n/g, "<br>")}</p>`;
  }).join("\n");

  return html;
}

// ===================== Settings: Gemini API key management =====================
const geminiKeyInput = document.getElementById("gemini-key-input");
const geminiKeyToggle = document.getElementById("gemini-key-toggle");
const geminiKeySaveBtn = document.getElementById("gemini-key-save-btn");
const geminiKeyStatus = document.getElementById("gemini-key-status");

// Show/hide key toggle
geminiKeyToggle.addEventListener("click", () => {
  const isHidden = geminiKeyInput.type === "password";
  geminiKeyInput.type = isHidden ? "text" : "password";
  geminiKeyToggle.textContent = isHidden ? "🙈" : "👁";
});

// Save key to Firestore
geminiKeySaveBtn.addEventListener("click", async () => {
  const key = geminiKeyInput.value.trim();
  if (!key) { showToast("Please enter your API key"); return; }
  geminiKeySaveBtn.disabled = true;
  geminiKeySaveBtn.textContent = "Saving…";
  try {
    await saveGeminiKey(key);
    geminiKeyStatus.textContent = "✓ Key saved";
    geminiKeyInput.value = "";
    geminiKeyInput.type = "password";
    geminiKeyToggle.textContent = "👁";
    showToast("Gemini API key saved ✦");
  } catch (err) {
    showToast("Could not save key: " + err.message);
  } finally {
    geminiKeySaveBtn.disabled = false;
    geminiKeySaveBtn.textContent = "Save key";
  }
});

// When Settings tab loads, show whether a key is already saved
async function loadSettingsKeyStatus() {
  const key = await loadGeminiKey();
  geminiKeyStatus.textContent = key ? "✓ API key is saved" : "No key saved yet";
}

// =====================================================================
// INSTALEARNING MODULE
// =====================================================================
let ilItems = [];
let ilUnsubscribe = null;
let ilEditingId = null;
let ilPendingImages = []; // [{base64, name}]

// Element refs
const ilFeed        = document.getElementById("il-feed");
const ilEmptyState  = document.getElementById("il-empty-state");
const ilSearchInput = document.getElementById("il-search-input");
const ilActiveTagFilter = document.getElementById("il-active-tag-filter");
const fabAddIl      = document.getElementById("fab-add-il");

const ilModal       = document.getElementById("il-modal");
const ilModalTitle  = document.getElementById("il-modal-title");
const ilModalClose  = document.getElementById("il-modal-close");
const ilText        = document.getElementById("il-text");
const ilLink        = document.getElementById("il-link");
const ilTags        = document.getElementById("il-tags");
attachTagAutocomplete(ilTags);
const ilFolder      = document.getElementById("il-folder");
const ilPriority    = document.getElementById("il-priority");
const ilSaveBtn     = document.getElementById("il-save-btn");
const ilCancelBtn   = document.getElementById("il-cancel-btn");
const ilDeleteBtn   = document.getElementById("il-delete-btn");
const ilImageInput  = document.getElementById("il-image-input");
const ilImageZone   = document.getElementById("il-image-zone");
const ilImageGrid   = document.getElementById("il-image-grid");

// Active tag filter for IL
let ilTagFilter = null;

ilActiveTagFilter.addEventListener("click", () => {
  ilTagFilter = null;
  ilActiveTagFilter.classList.add("hidden");
  renderILFeed();
});

ilSearchInput.addEventListener("input", () => renderILFeed());

// Subscribe IL items from Firestore
function subscribeILItems() {
  if (ilUnsubscribe) ilUnsubscribe();
  if (!currentUser) return;
  const ref = db.collection("users").doc(currentUser.uid).collection("ilItems")
    .orderBy("createdAt", "desc").limit(200);
  ilUnsubscribe = ref.onSnapshot((snap) => {
    ilItems = [];
    snap.forEach((doc) => ilItems.push({ id: doc.id, ...doc.data() }));
    // Also refresh allTags with IL tags
    updateAllTagsWithIL();
    if (activeView === "instalearning") renderILFeed();
  }, (err) => { console.error("IL items error", err); });
}

function updateAllTagsWithIL() {
  const set = new Set(allTags);
  ilItems.forEach((o) => (o.tags || []).forEach((t) => set.add(t)));
  allTags = Array.from(set).sort((a, b) => a.localeCompare(b));
}

// Render IL feed
function renderILFeed() {
  ilFeed.innerHTML = "";
  const q = ilSearchInput.value.trim().toLowerCase();
  const filtered = ilItems.filter((o) => {
    if (o.archived) return false;
    if (ilTagFilter && !(o.tags || []).includes(ilTagFilter)) return false;
    if (q) {
      const inText = (o.text || "").toLowerCase().includes(q);
      const inTags = (o.tags || []).some((t) => t.toLowerCase().includes(q));
      if (!inText && !inTags) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    ilEmptyState.classList.remove("hidden");
    return;
  }
  ilEmptyState.classList.add("hidden");

  filtered.forEach((o) => ilFeed.appendChild(buildILCard(o)));
}

function buildILCard(o) {
  const card = document.createElement("div");
  const p = o.priority || "medium";
  card.className = `il-card priority-${p}`;

  // Images
  const images = o.images || (o.imageBase64 ? [o.imageBase64] : []);
  if (images.length > 0) {
    const grid = document.createElement("div");
    const countClass = images.length === 1 ? "count-1"
      : images.length === 2 ? "count-2"
      : images.length === 3 ? "count-3" : "count-4plus";
    grid.className = `il-card-images ${countClass}`;

    const show = Math.min(images.length, 4);
    images.slice(0, show).forEach((src, i) => {
      if (i === 3 && images.length > 4) {
        const more = document.createElement("div");
        more.className = "il-img-more";
        more.textContent = `+${images.length - 3}`;
        more.addEventListener("click", () => openILLightbox(images, 3));
        grid.appendChild(more);
      } else {
        const img = document.createElement("img");
        img.className = "il-img";
        img.src = src;
        img.alt = "Learning image";
        img.addEventListener("click", () => openILLightbox(images, i));
        grid.appendChild(img);
      }
    });
    card.appendChild(grid);
  }

  // Body
  const body = document.createElement("div");
  body.className = "il-card-body";

  if (o.text) {
    const textEl = document.createElement("div");
    textEl.className = "il-card-text";
    textEl.textContent = o.text;
    body.appendChild(textEl);
  }

  if (o.link) {
    const linkEl = document.createElement("a");
    linkEl.className = "tile-link";
    linkEl.href = o.link;
    linkEl.target = "_blank";
    linkEl.rel = "noopener noreferrer";
    linkEl.textContent = "🔗 " + o.link;
    body.appendChild(linkEl);
  }

  // Footer: tags + time + actions
  const footer = document.createElement("div");
  footer.className = "il-card-footer";

  const tagsEl = document.createElement("div");
  tagsEl.className = "tile-tags";
  (o.tags || []).forEach((t) => {
    const chip = document.createElement("span");
    chip.className = "tag-chip clickable";
    chip.textContent = "#" + t;
    chip.addEventListener("click", (e) => {
      e.stopPropagation();
      ilTagFilter = t;
      ilActiveTagFilter.textContent = `#${t} ✕`;
      ilActiveTagFilter.classList.remove("hidden");
      renderILFeed();
    });
    tagsEl.appendChild(chip);
  });
  footer.appendChild(tagsEl);

  const actions = document.createElement("div");
  actions.className = "il-card-actions";

  const timeEl = document.createElement("span");
  timeEl.className = "tile-time";
  timeEl.style.marginRight = "6px";
  timeEl.textContent = formatTime(o.createdAt);

  const editBtn = document.createElement("button");
  editBtn.className = "il-action-btn";
  editBtn.title = "Edit";
  editBtn.innerHTML = "✎";
  editBtn.addEventListener("click", () => openILEditModal(o));
  actions.appendChild(editBtn);

  footer.appendChild(timeEl);
  footer.appendChild(actions);
  body.appendChild(footer);
  card.appendChild(body);
  return card;
}

// IL Lightbox (supports gallery swipe between images)
let ilLightboxImages = [];
let ilLightboxIndex = 0;

function openILLightbox(images, index) {
  ilLightboxImages = images;
  ilLightboxIndex = index;
  lightboxImg.src = images[index];
  lightboxRotation = 0;
  lightboxImg.style.transform = "rotate(0deg)";
  lightboxImg.style.maxWidth = "";
  lightboxImg.style.maxHeight = "";
  lightbox.classList.remove("hidden");
}

// Image zone handlers
ilImageZone.addEventListener("dragover", (e) => { e.preventDefault(); ilImageZone.classList.add("drag-over"); });
ilImageZone.addEventListener("dragleave", () => ilImageZone.classList.remove("drag-over"));
ilImageZone.addEventListener("drop", (e) => {
  e.preventDefault();
  ilImageZone.classList.remove("drag-over");
  handleILFiles(Array.from(e.dataTransfer.files));
});

ilImageInput.addEventListener("change", (e) => {
  handleILFiles(Array.from(e.target.files));
  e.target.value = "";
});

function handleILFiles(files) {
  const imageFiles = files.filter((f) => f.type.startsWith("image/"));
  Promise.all(imageFiles.map((f) => resizeImageToBase64(f, 1024, 0.75)))
    .then((bases) => {
      bases.forEach((b) => ilPendingImages.push(b));
      renderILImageGrid();
    })
    .catch((err) => { console.error(err); showToast("Could not process one or more images"); });
}

function renderILImageGrid() {
  ilImageGrid.innerHTML = "";
  ilPendingImages.forEach((src, i) => {
    const wrap = document.createElement("div");
    wrap.className = "il-thumb-wrap";
    const img = document.createElement("img");
    img.src = src;
    img.alt = "Preview";
    const rm = document.createElement("button");
    rm.className = "il-thumb-remove";
    rm.textContent = "✕";
    rm.addEventListener("click", () => {
      ilPendingImages.splice(i, 1);
      renderILImageGrid();
    });
    wrap.appendChild(img);
    wrap.appendChild(rm);
    ilImageGrid.appendChild(wrap);
  });
}

// Open create modal
fabAddIl.addEventListener("click", () => openILCreateModal());

function openILCreateModal() {
  ilEditingId = null;
  ilPendingImages = [];
  ilModalTitle.textContent = "New InstaLearning";
  ilDeleteBtn.classList.add("hidden");
  ilText.value = "";
  ilLink.value = "";
  ilTags.value = "";
  ilImageGrid.innerHTML = "";
  populateFolderSelect(ilFolder, getDefaultFolder());
  ilPriority.value = "medium";
  ilModal.classList.remove("hidden");
}

function openILEditModal(o) {
  ilEditingId = o.id;
  ilPendingImages = [...(o.images || [])];
  ilModalTitle.textContent = "Edit InstaLearning";
  ilDeleteBtn.classList.remove("hidden");
  ilText.value = o.text || "";
  ilLink.value = o.link || "";
  ilTags.value = (o.tags || []).join(", ");
  populateFolderSelect(ilFolder, o.folder || folders[0]);
  ilPriority.value = o.priority || "medium";
  renderILImageGrid();
  ilModal.classList.remove("hidden");
}

ilModalClose.addEventListener("click", () => ilModal.classList.add("hidden"));
ilCancelBtn.addEventListener("click", () => ilModal.classList.add("hidden"));

ilSaveBtn.addEventListener("click", async () => {
  const text = ilText.value.trim();
  const link = ilLink.value.trim();
  const tags = ilTags.value.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean);
  const folder = ilFolder.value;
  const priority = ilPriority.value;

  if (!text && !link && ilPendingImages.length === 0) {
    showToast("Add at least an image, text, or link");
    return;
  }
  if (link && !/^https?:\/\//i.test(link)) {
    showToast("Link should start with http:// or https://");
    return;
  }
  // Rough size check (Firestore doc limit ~1MB)
  const totalSize = ilPendingImages.reduce((s, b) => s + b.length, 0);
  if (totalSize > 900000) {
    showToast("Total image size too large. Remove some images or use smaller ones.");
    return;
  }

  const data = {
    text, link, tags, folder, priority,
    images: ilPendingImages,
    archived: false,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
  };

  ilSaveBtn.disabled = true;
  ilSaveBtn.textContent = "Saving…";
  try {
    const col = db.collection("users").doc(currentUser.uid).collection("ilItems");
    if (ilEditingId) {
      await col.doc(ilEditingId).update(data);
      showToast("InstaLearning updated");
    } else {
      data.createdAt = firebase.firestore.FieldValue.serverTimestamp();
      await col.add(data);
      showToast("InstaLearning saved");
    }
    ilModal.classList.add("hidden");
  } catch (err) {
    console.error(err);
    showToast("Save failed: " + err.message);
  } finally {
    ilSaveBtn.disabled = false;
    ilSaveBtn.textContent = "Save";
  }
});

ilDeleteBtn.addEventListener("click", async () => {
  if (!ilEditingId) return;
  if (!confirm("Delete this InstaLearning?")) return;
  try {
    await db.collection("users").doc(currentUser.uid).collection("ilItems").doc(ilEditingId).delete();
    ilModal.classList.add("hidden");
    showToast("Deleted");
  } catch (err) {
    console.error(err);
    showToast("Delete failed");
  }
});

// =====================================================================
// PRE-TRADE CHECKLIST MODULE
// =====================================================================
let checklists = {};      // { id: { name, items: [string] } }
let activeChecklistId = null;
let checklistChecked = new Set(); // item indices checked in current run
let checklistLogImageBase64 = null;

// Refs — checklist run modal
const checklistFab        = document.getElementById("checklist-fab");
const checklistModal      = document.getElementById("checklist-modal");
const checklistModalClose = document.getElementById("checklist-modal-close");
const checklistPicker     = document.getElementById("checklist-picker");
const checklistItemsBody  = document.getElementById("checklist-items-body");
const checklistScoreFill  = document.getElementById("checklist-score-fill");
const checklistScoreText  = document.getElementById("checklist-score-text");
const checklistResetBtn   = document.getElementById("checklist-reset-btn");
const checklistLogBtn     = document.getElementById("checklist-log-btn");

// Refs — result / log modal
const checklistResultModal = document.getElementById("checklist-result-modal");
const clResultClose        = document.getElementById("cl-result-close");
const clResultSummary      = document.getElementById("cl-result-summary");
const clOutcome            = document.getElementById("cl-outcome");
const clPreTrade           = document.getElementById("cl-pre-trade");
const clPostTrade          = document.getElementById("cl-post-trade");
const clChartImage         = document.getElementById("cl-chart-image");
const clChartPreview       = document.getElementById("cl-chart-preview");
const clChartPreviewImg    = document.getElementById("cl-chart-preview-img");
const clChartRemove        = document.getElementById("cl-chart-remove");
const clLinkTrade          = document.getElementById("cl-link-trade");
const clResultDismiss      = document.getElementById("cl-result-dismiss");
const clResultSave         = document.getElementById("cl-result-save");

// Refs — settings management
const clManageSelect  = document.getElementById("cl-manage-select");
const clNewBtn        = document.getElementById("cl-new-btn");
const clDeleteClBtn   = document.getElementById("cl-delete-cl-btn");
const clNameRow       = document.getElementById("cl-name-row");
const clNameInput     = document.getElementById("cl-name-input");
const clNameSaveBtn   = document.getElementById("cl-name-save-btn");
const clItemsEditor   = document.getElementById("cl-items-editor");
const clNewItemInput  = document.getElementById("cl-new-item-input");
const clAddItemBtn    = document.getElementById("cl-add-item-btn");

// ---- Firestore: load/save checklists ----
const CHECKLIST_DEFAULT_ID = "default";

function checklistRef() {
  return db.collection("users").doc(currentUser.uid).collection("checklists");
}

async function loadChecklists() {
  try {
    const snap = await checklistRef().get();
    checklists = {};
    snap.forEach((doc) => { checklists[doc.id] = doc.data(); });
    // Ensure a "default" checklist exists
    if (!checklists[CHECKLIST_DEFAULT_ID]) {
      const def = {
        name: "Default",
        items: [
          "Market trend confirmed (H1/H4)",
          "Setup aligns with my strategy",
          "Risk/Reward at least 1:2",
          "Stop loss placed at key level",
          "Position size calculated",
          "No news event in next 30 min",
          "Entry price matches plan",
          "I am in the right mental state",
        ],
      };
      await checklistRef().doc(CHECKLIST_DEFAULT_ID).set(def);
      checklists[CHECKLIST_DEFAULT_ID] = def;
    }
    renderChecklistPicker();
    renderChecklistManageSelect();
  } catch (err) {
    console.error("loadChecklists error", err);
  }
}

async function saveChecklist(id, data) {
  await checklistRef().doc(id).set(data);
  checklists[id] = data;
}

async function deleteChecklist(id) {
  if (id === CHECKLIST_DEFAULT_ID) { showToast("Can't delete the default checklist"); return; }
  await checklistRef().doc(id).delete();
  delete checklists[id];
}

// ---- Checklist run modal ----
checklistFab.addEventListener("click", () => openChecklistModal());

function openChecklistModal() {
  renderChecklistPicker();
  const firstId = Object.keys(checklists)[0] || CHECKLIST_DEFAULT_ID;
  activeChecklistId = checklistPicker.value || firstId;
  checklistChecked = new Set();
  renderChecklistItems();
  checklistModal.classList.remove("hidden");
}

checklistModalClose.addEventListener("click", () => checklistModal.classList.add("hidden"));

checklistPicker.addEventListener("change", () => {
  activeChecklistId = checklistPicker.value;
  checklistChecked = new Set();
  renderChecklistItems();
});

function renderChecklistPicker() {
  const prev = checklistPicker.value;
  checklistPicker.innerHTML = "";
  Object.entries(checklists).forEach(([id, cl]) => {
    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = cl.name || id;
    checklistPicker.appendChild(opt);
  });
  if (prev && checklists[prev]) checklistPicker.value = prev;
}

function renderChecklistItems() {
  const cl = checklists[activeChecklistId];
  if (!cl) { checklistItemsBody.innerHTML = "<p style='color:var(--text-dim);padding:16px'>No items.</p>"; return; }
  checklistItemsBody.innerHTML = "";
  (cl.items || []).forEach((item, i) => {
    const row = document.createElement("div");
    row.className = "checklist-item-row" + (checklistChecked.has(i) ? " checked" : "");
    row.addEventListener("click", () => {
      if (checklistChecked.has(i)) checklistChecked.delete(i);
      else checklistChecked.add(i);
      row.classList.toggle("checked", checklistChecked.has(i));
      updateChecklistScore();
    });

    const circle = document.createElement("div");
    circle.className = "checklist-item-check";
    circle.textContent = checklistChecked.has(i) ? "✓" : "";

    const text = document.createElement("span");
    text.className = "checklist-item-text";
    text.textContent = item;

    row.appendChild(circle);
    row.appendChild(text);
    checklistItemsBody.appendChild(row);
  });
  updateChecklistScore();
}

function updateChecklistScore() {
  const cl = checklists[activeChecklistId];
  if (!cl) return;
  const total = (cl.items || []).length;
  const passed = checklistChecked.size;
  const pct = total > 0 ? Math.round((passed / total) * 100) : 0;
  checklistScoreFill.style.width = pct + "%";
  checklistScoreText.textContent = `${passed} / ${total} passed`;
  // Colour the fill based on score
  checklistScoreFill.style.background =
    pct === 100 ? "var(--grad-green)"
    : pct >= 70 ? "linear-gradient(90deg, var(--medium), #F5AA60)"
    : "linear-gradient(90deg, var(--high), #F08060)";
}

checklistResetBtn.addEventListener("click", () => {
  checklistChecked = new Set();
  renderChecklistItems();
});

checklistLogBtn.addEventListener("click", () => {
  try {
    const cl = checklists[activeChecklistId];
    if (!cl) {
      showToast("No checklist selected");
      return;
    }
    const total = (cl.items || []).length;
    const passed = checklistChecked.size;
    const failed = (cl.items || []).filter((_, i) => !checklistChecked.has(i));
    const pct = total > 0 ? Math.round((passed / total) * 100) : 0;

    // Build result summary
    clResultSummary.innerHTML = "";
    const scoreEl = document.createElement("div");
    scoreEl.className = `cl-result-score-big ${pct === 100 ? "all-pass" : pct >= 70 ? "partial" : "low-pass"}`;
    scoreEl.textContent = `${passed} / ${total}`;
    const labelEl = document.createElement("div");
    labelEl.className = "cl-result-label";
    labelEl.textContent = pct === 100 ? "All checks passed ✓" : `${pct}% passed — ${total - passed} item${total - passed !== 1 ? "s" : ""} not confirmed`;
    clResultSummary.appendChild(scoreEl);
    clResultSummary.appendChild(labelEl);

    if (failed.length > 0) {
      const failList = document.createElement("div");
      failList.className = "cl-failed-list";
      failed.forEach((item) => {
        const el = document.createElement("div");
        el.className = "cl-failed-item";
        el.textContent = item;
        failList.appendChild(el);
      });
      clResultSummary.appendChild(failList);
    }

    // Populate trade log link dropdown with today's / this month's trade entries.
    // Defensive: tolerate trades with missing/odd "date" fields without throwing.
    clLinkTrade.innerHTML = "<option value=''>— Not linked —</option>";
    const todayStr = new Date().toISOString().slice(0, 10);
    const monthStr = todayStr.slice(0, 7);
    (trades || []).forEach((t) => {
      const tDate = typeof t.date === "string" ? t.date : "";
      if (tDate === todayStr || tDate.startsWith(monthStr)) {
        const opt = document.createElement("option");
        opt.value = t.id;
        opt.textContent = `${tDate || "Undated"} — ${t.numTrades || 0} trades (Net: ${formatNum(t.netPL)})`;
        clLinkTrade.appendChild(opt);
      }
    });

    // Reset log fields
    clOutcome.value = "";
    clPreTrade.value = "";
    clPostTrade.value = "";
    clChartPreview.classList.add("hidden");
    checklistLogImageBase64 = null;
    clChartImage.value = "";

    checklistModal.classList.add("hidden");
    checklistResultModal.classList.remove("hidden");
  } catch (err) {
    console.error("checklistLogBtn handler error:", err);
    showToast("Could not open log screen: " + err.message);
  }
});

// Chart image for log
clChartImage.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  resizeImageToBase64(file, 1024, 0.75).then((b) => {
    checklistLogImageBase64 = b;
    clChartPreviewImg.src = b;
    clChartPreview.classList.remove("hidden");
  });
});
clChartRemove.addEventListener("click", () => {
  checklistLogImageBase64 = null;
  clChartImage.value = "";
  clChartPreview.classList.add("hidden");
});

clResultClose.addEventListener("click", () => {
  checklistResultModal.classList.add("hidden");
  checklistModal.classList.remove("hidden"); // go back to checklist
});

clResultDismiss.addEventListener("click", () => {
  checklistResultModal.classList.add("hidden");
  showToast("Checklist run dismissed (not logged)");
});

clResultSave.addEventListener("click", async () => {
  const cl = checklists[activeChecklistId];
  const total = (cl?.items || []).length;
  const passed = checklistChecked.size;
  const logData = {
    type: "checklistRun",
    checklistId: activeChecklistId,
    checklistName: cl?.name || "Default",
    total,
    passed,
    failed: (cl?.items || []).filter((_, i) => !checklistChecked.has(i)),
    outcome: clOutcome.value || null,
    preTrade: clPreTrade.value.trim() || null,
    postTrade: clPostTrade.value.trim() || null,
    chartImage: checklistLogImageBase64 || null,
    linkedTradeId: clLinkTrade.value || null,
    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
  };

  clResultSave.disabled = true;
  clResultSave.textContent = "Saving…";
  try {
    await db.collection("users").doc(currentUser.uid).collection("checklistLogs").add(logData);
    checklistResultModal.classList.add("hidden");
    showToast("Checklist run logged ✓");
  } catch (err) {
    console.error(err);
    showToast("Could not save log: " + err.message);
  } finally {
    clResultSave.disabled = false;
    clResultSave.textContent = "Save log";
  }
});

// ---- Checklist management in Settings ----
function renderChecklistManageSelect() {
  const prev = clManageSelect.value;
  clManageSelect.innerHTML = "";
  Object.entries(checklists).forEach(([id, cl]) => {
    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = cl.name || id;
    clManageSelect.appendChild(opt);
  });
  if (prev && checklists[prev]) clManageSelect.value = prev;
  renderChecklistItemsEditor();
}

clManageSelect.addEventListener("change", () => renderChecklistItemsEditor());

function renderChecklistItemsEditor() {
  const id = clManageSelect.value;
  const cl = checklists[id];
  clItemsEditor.innerHTML = "";
  if (!cl) return;
  (cl.items || []).forEach((item, i) => {
    const row = document.createElement("div");
    row.className = "cl-setting-item";

    const drag = document.createElement("span");
    drag.className = "cl-setting-drag-handle";
    drag.textContent = "⠿";

    const text = document.createElement("span");
    text.className = "cl-setting-item-text";
    text.textContent = item;

    const del = document.createElement("button");
    del.className = "cl-setting-delete";
    del.textContent = "✕";
    del.addEventListener("click", async () => {
      const updated = { ...cl, items: cl.items.filter((_, j) => j !== i) };
      await saveChecklist(id, updated);
      renderChecklistManageSelect();
      renderChecklistPicker();
    });

    row.appendChild(drag);
    row.appendChild(text);
    row.appendChild(del);
    clItemsEditor.appendChild(row);
  });
}

clNewBtn.addEventListener("click", () => {
  clNameRow.classList.toggle("hidden");
  clNameInput.value = "";
  if (!clNameRow.classList.contains("hidden")) clNameInput.focus();
});

clNameSaveBtn.addEventListener("click", async () => {
  const name = clNameInput.value.trim();
  if (!name) { showToast("Enter a name"); return; }
  const id = "cl_" + Date.now();
  await saveChecklist(id, { name, items: [] });
  clManageSelect.value = id;
  clNameRow.classList.add("hidden");
  clNameInput.value = "";
  renderChecklistManageSelect();
  renderChecklistPicker();
  showToast(`"${name}" created`);
});

clDeleteClBtn.addEventListener("click", async () => {
  const id = clManageSelect.value;
  if (!id || !checklists[id]) return;
  if (!confirm(`Delete checklist "${checklists[id].name}"? This cannot be undone.`)) return;
  try {
    await deleteChecklist(id);
    renderChecklistManageSelect();
    renderChecklistPicker();
    showToast("Checklist deleted");
  } catch (err) {
    showToast("Could not delete: " + err.message);
  }
});

clAddItemBtn.addEventListener("click", async () => {
  const text = clNewItemInput.value.trim();
  if (!text) return;
  const id = clManageSelect.value;
  const cl = checklists[id];
  if (!cl) return;
  const updated = { ...cl, items: [...(cl.items || []), text] };
  await saveChecklist(id, updated);
  clNewItemInput.value = "";
  renderChecklistItemsEditor();
  renderChecklistPicker();
  showToast("Item added");
});

clNewItemInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") clAddItemBtn.click();
});

// =====================================================================
// EXPORT MODULE (CSV / PDF)
// =====================================================================
const exportOpenBtn       = document.getElementById("export-open-btn");
const exportModal         = document.getElementById("export-modal");
const exportModalClose    = document.getElementById("export-modal-close");
const exportFormatSelect  = document.getElementById("export-format-select");
const exportFormatHint    = document.getElementById("export-format-hint");
const exportRangeSelect   = document.getElementById("export-range-select");
const exportCustomRow     = document.getElementById("export-custom-range-row");
const exportStartDate     = document.getElementById("export-start-date");
const exportEndDate       = document.getElementById("export-end-date");
const exportIncludeObs    = document.getElementById("export-include-obs");
const exportIncludeTrades = document.getElementById("export-include-trades");
const exportPreviewCount  = document.getElementById("export-preview-count");
const exportCancelBtn     = document.getElementById("export-cancel-btn");
const exportConfirmBtn    = document.getElementById("export-confirm-btn");

exportOpenBtn.addEventListener("click", () => {
  exportFormatSelect.value = "csv";
  exportRangeSelect.value = "all";
  exportCustomRow.classList.add("hidden");
  exportIncludeObs.checked = true;
  exportIncludeTrades.checked = true;
  updateExportHintAndPreview();
  exportModal.classList.remove("hidden");
});

exportModalClose.addEventListener("click", () => exportModal.classList.add("hidden"));
exportCancelBtn.addEventListener("click", () => exportModal.classList.add("hidden"));

exportFormatSelect.addEventListener("change", updateExportHintAndPreview);
exportRangeSelect.addEventListener("change", () => {
  exportCustomRow.classList.toggle("hidden", exportRangeSelect.value !== "custom");
  updateExportHintAndPreview();
});
exportStartDate.addEventListener("change", updateExportHintAndPreview);
exportEndDate.addEventListener("change", updateExportHintAndPreview);
exportIncludeObs.addEventListener("change", updateExportHintAndPreview);
exportIncludeTrades.addEventListener("change", updateExportHintAndPreview);

function getExportDateRange() {
  const mode = exportRangeSelect.value;
  const now = new Date();
  let start = null, end = null;

  if (mode === "all") {
    return { start: null, end: null };
  } else if (mode === "month") {
    start = new Date(now.getFullYear(), now.getMonth(), 1);
    end = now;
  } else if (mode === "week") {
    start = new Date(now);
    const day = start.getDay();
    const diffToMonday = (day === 0) ? 6 : day - 1;
    start.setDate(start.getDate() - diffToMonday);
    start.setHours(0, 0, 0, 0);
    end = now;
  } else if (mode === "custom") {
    if (exportStartDate.value) start = new Date(exportStartDate.value + "T00:00:00");
    if (exportEndDate.value) end = new Date(exportEndDate.value + "T23:59:59");
  }
  return { start, end };
}

function filterObsByRange(start, end) {
  return observations.filter((o) => {
    if (!o.createdAt || !o.createdAt.toDate) return false;
    const d = o.createdAt.toDate();
    if (start && d < start) return false;
    if (end && d > end) return false;
    return true;
  });
}

function filterTradesByRange(start, end) {
  return trades.filter((t) => {
    if (!t.date) return false;
    const d = new Date(t.date + "T12:00:00"); // noon avoids TZ edge issues for date-only strings
    if (start && d < start) return false;
    if (end && d > end) return false;
    return true;
  });
}

function updateExportHintAndPreview() {
  const isPdf = exportFormatSelect.value === "pdf";
  exportFormatHint.textContent = isPdf
    ? "PDF includes images inline and opens your browser's print/save dialog."
    : "CSV is a spreadsheet file. Images aren't embedded — a \"Has Image\" column is included instead.";

  const { start, end } = getExportDateRange();
  const obsCount = exportIncludeObs.checked ? filterObsByRange(start, end).length : 0;
  const tradeCount = exportIncludeTrades.checked ? filterTradesByRange(start, end).length : 0;
  exportPreviewCount.textContent = `Will export ${obsCount} observation${obsCount !== 1 ? "s" : ""} and ${tradeCount} trade log entr${tradeCount !== 1 ? "ies" : "y"}.`;
}

exportConfirmBtn.addEventListener("click", () => {
  if (!exportIncludeObs.checked && !exportIncludeTrades.checked) {
    showToast("Select at least one data type to export");
    return;
  }
  if (exportRangeSelect.value === "custom" && !exportStartDate.value && !exportEndDate.value) {
    showToast("Pick at least a start or end date for the custom range");
    return;
  }

  const { start, end } = getExportDateRange();
  const obsData = exportIncludeObs.checked ? filterObsByRange(start, end) : [];
  const tradeData = exportIncludeTrades.checked ? filterTradesByRange(start, end) : [];

  if (obsData.length === 0 && tradeData.length === 0) {
    showToast("Nothing to export in this range");
    return;
  }

  if (exportFormatSelect.value === "csv") {
    exportToCSV(obsData, tradeData);
  } else {
    exportToPDF(obsData, tradeData);
  }
  exportModal.classList.add("hidden");
});

// ---- CSV export ----
function csvEscape(val) {
  const s = val === null || val === undefined ? "" : String(val);
  if (/[",\n]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function csvRow(cells) {
  return cells.map(csvEscape).join(",") + "\r\n";
}

function exportToCSV(obsData, tradeData) {
  let csv = "";

  if (obsData.length > 0) {
    csv += csvRow(["=== OBSERVATIONS ==="]);
    csv += csvRow(["Date", "Time", "Text", "Link", "Tags", "Folder", "Priority", "Category", "Has Image", "Image Pending", "Archived"]);
    // Sort newest first for readability
    const sorted = [...obsData].sort((a, b) => getCreatedTime(b) - getCreatedTime(a));
    sorted.forEach((o) => {
      const d = o.createdAt && o.createdAt.toDate ? o.createdAt.toDate() : null;
      csv += csvRow([
        d ? getLocalDateKey({ toDate: () => d }) : "",
        d ? d.toLocaleTimeString() : "",
        o.text || "",
        o.link || "",
        (o.tags || []).join("; "),
        o.folder || "",
        o.priority || "medium",
        o.category || "",
        o.imageBase64 ? "Yes" : "No",
        o.imagePending ? "Yes" : "No",
        o.archived ? "Yes" : "No",
      ]);
    });
    csv += csvRow([]); // blank separator line
  }

  if (tradeData.length > 0) {
    csv += csvRow(["=== TRADE LOG ==="]);
    csv += csvRow(["Date", "Capital", "No. of Trades", "Gross P/L", "Net P/L", "Duration", "Comments"]);
    const sortedTrades = [...tradeData].sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    sortedTrades.forEach((t) => {
      csv += csvRow([
        t.date || "",
        t.capital != null ? t.capital : "",
        t.numTrades != null ? t.numTrades : "",
        t.grossPL != null ? t.grossPL : "",
        t.netPL != null ? t.netPL : "",
        t.duration || "",
        t.comments || "",
      ]);
    });
  }

  // Prepend BOM so Excel correctly detects UTF-8 (important for ₹, emoji, etc.)
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  downloadBlob(blob, `trade-journal-export-${todayKey()}.csv`);
  showToast("CSV exported");
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ---- PDF export (via browser print) ----
function exportToPDF(obsData, tradeData) {
  const sortedObs = [...obsData].sort((a, b) => getCreatedTime(b) - getCreatedTime(a));
  const sortedTrades = [...tradeData].sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  const win = window.open("", "_blank");
  if (!win) {
    showToast("Pop-up blocked — please allow pop-ups for this site to export PDF");
    return;
  }

  const priorityColor = { low: "#1E9E42", medium: "#C06010", high: "#CC2822" };

  let obsHtml = "";
  if (sortedObs.length > 0) {
    obsHtml += `<h1>Observations</h1>`;
    sortedObs.forEach((o) => {
      const d = o.createdAt && o.createdAt.toDate ? o.createdAt.toDate() : null;
      const dateStr = d ? d.toLocaleDateString(undefined, { weekday: "short", year: "numeric", month: "short", day: "numeric" }) + " · " + d.toLocaleTimeString() : "Undated";
      const pColor = priorityColor[o.priority || "medium"];
      obsHtml += `
        <div class="entry" style="border-left-color:${pColor}">
          <div class="entry-meta">
            <span class="entry-date">${escapeHtml(dateStr)}</span>
            <span class="entry-tags">${escapeHtml(o.folder || "")}${o.priority ? " · " + o.priority.toUpperCase() : ""}</span>
          </div>
          ${o.text ? `<p class="entry-text">${escapeHtml(o.text).replace(/\n/g, "<br>")}</p>` : ""}
          ${o.imageBase64 ? `<img class="entry-img" src="${o.imageBase64}" />` : ""}
          ${o.link ? `<p class="entry-link">🔗 ${escapeHtml(o.link)}</p>` : ""}
          ${(o.tags || []).length ? `<p class="entry-chips">${(o.tags || []).map((t) => `<span class="chip">#${escapeHtml(t)}</span>`).join(" ")}</p>` : ""}
        </div>`;
    });
  }

  let tradeHtml = "";
  if (sortedTrades.length > 0) {
    const totalNet = sortedTrades.reduce((s, t) => s + (Number(t.netPL) || 0), 0);
    const totalGross = sortedTrades.reduce((s, t) => s + (Number(t.grossPL) || 0), 0);
    const totalTrades = sortedTrades.reduce((s, t) => s + (Number(t.numTrades) || 0), 0);
    tradeHtml += `<h1>Trade Log</h1>`;
    tradeHtml += `
      <table class="trade-table">
        <thead>
          <tr><th>Date</th><th>Capital</th><th>Trades</th><th>Gross P/L</th><th>Net P/L</th><th>Duration</th><th>Comments</th></tr>
        </thead>
        <tbody>
          ${sortedTrades.map((t) => `
            <tr>
              <td>${escapeHtml(t.date || "")}</td>
              <td>${t.capital != null ? formatNum(t.capital) : ""}</td>
              <td>${t.numTrades != null ? t.numTrades : ""}</td>
              <td>${t.grossPL != null ? formatNum(t.grossPL) : ""}</td>
              <td class="${Number(t.netPL) >= 0 ? "pos" : "neg"}">${t.netPL != null ? formatNum(t.netPL) : ""}</td>
              <td>${escapeHtml(t.duration || "")}</td>
              <td>${escapeHtml(t.comments || "")}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <p class="trade-summary">Total trades: <b>${totalTrades}</b> &nbsp;|&nbsp; Total gross P/L: <b>${formatNum(totalGross)}</b> &nbsp;|&nbsp; Total net P/L: <b>${formatNum(totalNet)}</b></p>
    `;
  }

  const { start, end } = getExportDateRange();
  const rangeLabel = !start && !end ? "All time"
    : `${start ? start.toLocaleDateString() : "…"} – ${end ? end.toLocaleDateString() : "…"}`;

  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Trade Journal Export</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Helvetica, Arial, sans-serif; color: #1a1a1a; margin: 0; padding: 32px; max-width: 800px; margin: 0 auto; }
  h1 { font-size: 20px; border-bottom: 2px solid #1a1a1a; padding-bottom: 8px; margin: 32px 0 16px; }
  h1:first-child { margin-top: 0; }
  .export-header { margin-bottom: 24px; }
  .export-header .title { font-size: 24px; font-weight: 700; margin: 0; }
  .export-header .range { color: #666; font-size: 13px; margin: 4px 0 0; }
  .entry { border-left: 4px solid #999; padding: 10px 14px; margin-bottom: 14px; background: #fafafa; border-radius: 4px; page-break-inside: avoid; }
  .entry-meta { display: flex; justify-content: space-between; font-size: 11px; color: #666; margin-bottom: 6px; font-family: monospace; }
  .entry-text { font-size: 14px; line-height: 1.5; margin: 0 0 8px; white-space: pre-wrap; }
  .entry-img { max-width: 100%; max-height: 320px; display: block; margin: 8px 0; border-radius: 4px; }
  .entry-link { font-size: 12px; color: #1a6fe8; margin: 4px 0; word-break: break-all; }
  .entry-chips { margin: 6px 0 0; }
  .chip { display: inline-block; font-size: 11px; font-family: monospace; color: #1a6fe8; background: #e8f0ff; border-radius: 4px; padding: 2px 7px; margin-right: 4px; }
  .trade-table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 10px; }
  .trade-table th, .trade-table td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
  .trade-table th { background: #f0f0f0; font-weight: 700; }
  .pos { color: #1e9e42; font-weight: 600; }
  .neg { color: #cc2822; font-weight: 600; }
  .trade-summary { font-size: 13px; margin-top: 8px; }
  @media print {
    body { padding: 16px; }
    .entry { background: #fff; border: 1px solid #ccc; border-left-width: 4px; }
  }
</style>
</head>
<body>
  <div class="export-header">
    <p class="title">Trade Journal Export</p>
    <p class="range">${escapeHtml(rangeLabel)} &nbsp;·&nbsp; Generated ${new Date().toLocaleString()}</p>
  </div>
  ${obsHtml}
  ${tradeHtml}
</body>
</html>`;

  win.document.open();
  win.document.write(html);
  win.document.close();

  // Give images time to load (base64 is instant, but be safe) then trigger print dialog.
  // Guarded so we never call print() twice in browsers where both paths fire.
  let printTriggered = false;
  function triggerPrintOnce() {
    if (printTriggered) return;
    printTriggered = true;
    try { win.print(); } catch (e) { /* window may already be closed */ }
  }
  win.onload = () => setTimeout(triggerPrintOnce, 400);
  setTimeout(triggerPrintOnce, 800); // fallback in case onload doesn't fire after document.write

  showToast("Opening print dialog — choose \"Save as PDF\"");
}
